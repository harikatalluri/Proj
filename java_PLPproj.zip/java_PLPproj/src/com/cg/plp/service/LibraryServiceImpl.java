package com.cg.plp.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookTransactionBean;
import com.cg.plp.bean.UserBean;
import com.cg.plp.dao.*;
import com.cg.plp.exception.LibraryException;

public class LibraryServiceImpl implements ILibraryService
{
	ILibraryDao libraryDaoImpl=new LibraryDoaImpl();
	
	public boolean isNameValid(String username)
	{
			Pattern pattern=Pattern.compile("[A-Z][a-zA-Z]{5,19}");
			Matcher matcher=pattern.matcher(username);
			if(!matcher.find())
			{
				System.out.println("Enter a name that should start with capital letter and length should me minimum of 6 characters");
				return true;
			}
			else
				return false;
	}
	
	public boolean isEmailValid(String emailid)
	{
		Pattern pattern=Pattern.compile("^[A-Za-z0-9]{1,20}[@]{1}[A-Za-z0-9.]{1,20}");
		Matcher matcher=pattern.matcher(emailid);
		if(!matcher.find())
		{
			System.out.println("Email id should have @ character");
			return true;
		}
		else
			return false;
	}
	
	public boolean IsPhnNumberValid(String mobileNumber)
	{
		Pattern pattern=Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher matcher=pattern.matcher(mobileNumber);
		if(!matcher.find())
		{
			System.out.println("Phone number should contain exactly 10 digits and first numbers should not be 0");
			return true;
		}
		else
			return false;
	}
	
	
	public String getName(String id) throws LibraryException
	{
		return libraryDaoImpl.getName(id);
	}
	public int isUserValid(String id,String pwd) throws LibraryException
	{
		return libraryDaoImpl.isUserValid(id,pwd);
	}
	
	public int isBookAvailable(String bookid) throws LibraryException
	{
		return libraryDaoImpl.isBookAvailable(bookid);
	}
	
	public int addRequest(String userId, String bookId) throws LibraryException
	{
		return libraryDaoImpl.addRequest(userId, bookId);
	}

	@Override
	public int registerUser(UserBean userBean)  throws LibraryException
	{
		int userId=libraryDaoImpl.registerUserDao(userBean);
		return userId;
	}

	@Override
	public boolean addBooks(BookBean bookBean) throws LibraryException
	{
		return libraryDaoImpl.addBooks(bookBean);
	}

	@Override
	public boolean removeBook(String bookId) throws LibraryException
	{
		return libraryDaoImpl.removeBook(bookId);
	}

	@Override
	public int returnBook(String transactionId, String bookId) throws LibraryException
	{
		return libraryDaoImpl.returnBook(transactionId,bookId);
	}

	@Override
	public ArrayList displayRequests() throws LibraryException 
	{
		return libraryDaoImpl.displayRequests();
	}

	@Override
	public String grantBook(String registrationid, String bookId) throws LibraryException 
	{
		return libraryDaoImpl.grantBook(registrationid, bookId);
	}

}
