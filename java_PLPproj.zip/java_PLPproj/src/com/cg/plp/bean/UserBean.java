package com.cg.plp.bean;

public class UserBean
{
	private String userId=null;
	private String password=null;
	private String name=null;
	private String emailId=null;
	private String address=null;
	private String gender=null;
	private String phoneNum=null;
	private String librarian=null;
	
	public String getUserId()
	{
		return userId;
	}
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	
	public String getPassword()
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getEmailId()
	{
		return emailId;
	}
	public void setEmailId(String emailId)
	{
		this.emailId = emailId;
	}
	
	public String getAddress()
	{
		return address;
	}
	public void setAddress(String address) 
	{
		this.address = address;
	}
	
	public String getGender()
	{
		return gender;
	}
	public void setGender(String gender)
	{
		this.gender = gender;
	}
	
	public String getPhoneNum()
	{
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) 
	{
		this.phoneNum = phoneNum;
	}
	
	public String getLibrarian() 
	{
		return librarian;
	}
	public void setLibrarian(String librarian)
	{
		this.librarian = librarian;
	}
	
	
}
