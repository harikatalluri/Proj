package com.cg.eis.pl;

import com.cg.eis.service.*;

public class EmployeeMain 
{
	public static void main(String args[])
	{	
		IEmployeeService iempser=null;
		iempser=new EmployeeClass();
		
		iempser.getDetails();
		iempser.getScheme();
		iempser.displayDetails();
	}

}
