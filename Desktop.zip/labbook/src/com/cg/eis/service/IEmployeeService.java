package com.cg.eis.service;

public interface IEmployeeService 
{
	public abstract void getDetails();
	public abstract void getScheme();
	public abstract void displayDetails();
}
