package com.cg.eis.service;
import java.util.*;
import com.cg.eis.bean.Employee;

public class EmployeeClass implements IEmployeeService
{
	Employee emp=new Employee();
	public void getDetails()
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter your id: ");
		emp.setId(scan.nextInt());
		System.out.println("Enter your name: ");
		emp.setName(scan.next());
		System.out.println("Enter your salary: ");
		emp.setSalary(scan.nextInt());
		scan.close();		
	}
	
	public void getScheme()
	{
		if(emp.getSalary()<5000)
		{
			emp.setScheme("No scheme");
			emp.setDesignation("Clerk");
		}
		else if(emp.getSalary()>5000 && emp.getSalary()<20000)
		{	
			emp.setScheme("Scheme C");
			emp.setDesignation("System Associate");
		}
		else if(emp.getSalary()>=20000 && emp.getSalary()<40000)
		{
			emp.setScheme("Scheme B");
			emp.setDesignation("Programmer");
		}
		else
		{	
			emp.setScheme("Scheme A");
			emp.setDesignation("Manager");
		}
	}
	
	public void displayDetails()
	{
		System.out.println("Employee id is: "+emp.getId());
		System.out.println("Employee name is: "+emp.getName());
		System.out.println("Employee salary is: "+emp.getSalary());
		System.out.println("Employee designation is: "+emp.getDesignation());
		System.out.println("Scheme of employee is: "+emp.getScheme());
	}
}
