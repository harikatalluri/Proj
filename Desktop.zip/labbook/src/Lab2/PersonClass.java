package Lab2;

public class PersonClass 
{
	public enum gender{Female,Male};
	
		private String firstName;
		private String lastName;
		private gender gender;
		private long phnnum;
		
		public long getPhnnum() {
			return phnnum;
		}
		public void setPhnnum(long phnnum) {
			this.phnnum = phnnum;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public gender getGender() {
			return gender;
		}
		public void setGender(gender gender) {
			this.gender = gender;
		}
		
		public PersonClass()
		{
			
		}
		
		public PersonClass(String firstName, String lastName, gender gender, long phnnum) 
		{
			this.firstName = firstName;
			this.lastName = lastName;
			this.gender = gender;
			this.phnnum = phnnum;
		}

		public void display()
		{
			System.out.println("First Name: "+this.firstName);
			System.out.println("Last Name: "+this.lastName);
			System.out.println("Gender: "+this.gender);
			System.out.println("Phone number: "+this.phnnum);
			System.out.println("\n");
		}
}
