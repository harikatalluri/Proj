package Lab2;

import java.util.*;
import Lab2.PersonClass.gender;

public class PersonMain 
{
	Scanner sc=new Scanner(System.in);
	gender getGender()
	{
		System.out.println("Enter gender: ");
		char g=sc.next().charAt(0);
		if(g=='F')
			return gender.Female;
		else
			return gender.Male;
	}
	
	public static void main(String[] args) 
	{
		PersonMain p=new PersonMain();
		gender gen = p.getGender();
		PersonClass person1=new PersonClass("Harika","Talluri",gen,1826378300);
		PersonClass person2=new PersonClass("Hari","Talluri",gen,1092987654);
		System.out.println("Person Details:");
		System.out.println("------------------");
		person1.display();
		person2.display();
	}

}
