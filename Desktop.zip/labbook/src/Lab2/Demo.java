package Lab2;

import java.util.*;

class Demo {
	public static void main(String args[]) 
	{
		String s="";
		System.out.println(s.equals(""));
	}
}


/*package Lab2;

import java.util.*;

class Demo {
	public static void main(String args[]) 
	{
		// create a hash set
		Set hs = new HashSet();
		// add elements to the hash set
		hs.add("Alex");
		hs.add("Bob");
		hs.add("Bin");
		hs.add("Bunny");
		hs.add("Zack");
		hs.add("Cad");
		hs.add("Box");
		System.out.println(hs);
	}
}*/



/*package Lab2;
import java.util.Arrays;

public class Demo {

	public static void main(String[] args) 
	{
		int arr[]={10,11,12,13,14,15};
		//Arrays.sort(arr);
		//for(int i=0;i<6;i++)
		//	System.out.println(arr[i]);
		int num=Arrays.binarySearch(arr,14);	//for binary search give input in ascending order
		System.out.println("num: "+num);
	}

}*/
