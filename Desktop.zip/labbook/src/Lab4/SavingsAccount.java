package Lab4;

public class SavingsAccount extends Account 
{
	private final double minBalance=500;
	public static void main(String args[])
	{
		SavingsAccount s=new SavingsAccount();
	}
	
	void withdraw(double cash)
	{
		if(minBalance<500)
			System.out.println("Minimum balance should be greater than 500");
		else
		{
			if(s.getBalance()-cash>=minBalance)
				this.balance=this.balance-cash;
			else
				System.out.println("Insufficient amount for withdrawl");
		}	
	}
}
