package Lab4;

public class CurrentAccount extends Account
{

}
