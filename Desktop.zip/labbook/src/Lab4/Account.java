package Lab4;

public class Account 
{	
	private static long accNum=1000;
	private long accountNumber;
	private double balance;
	Person accHolder;
	
	public long getAccountNumber() {
		return accountNumber;
	}
	
	public long getAccNum() {
		return accNum;
	}
	public double getBalance() {
		return balance;
	}
	
	void deposit(double cash)
	{
		this.balance=this.balance+cash;
	}
	
	void withdraw(double cash)
	{
		if(this.balance-cash>=500)
			this.balance=this.balance-cash;	
	}
	
	Account()
	{
		
	}
	
	Account(double balance,Person accHolder)
	{
		++accNum;
		this.accountNumber=accNum;
		this.balance=balance;
		this.accHolder=accHolder;
	}
	
	public static void main(String args[])
	{
		Person p1=new Person("Smith",20);
		Person p2=new Person("Kathy",30);
		Account a1=new Account(2000,p1);
		Account a2=new Account(3000,p2);
		a1.deposit(2000);
		a2.withdraw(2000);
		System.out.println(a1);
		System.out.println(a2);
	}
	
	public String toString()
	{
		return "Person name: "+this.accHolder.getName()+
				"\nAccount number: "+this.accountNumber+
				"\nBalance: "+this.balance+"\n";
	}

}
