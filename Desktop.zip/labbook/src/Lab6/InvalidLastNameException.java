package Lab6;

public class InvalidLastNameException extends Exception
{				
	public String lastName;
	InvalidLastNameException(String s)
	{
		lastName=s;
	}
}
