package Lab6;

class PersonException 
{
    static void compute1(String s) throws InvalidFirstNameException 
    {
		 if (s.equals("null"))
			throw new InvalidFirstNameException(s); 
    }
    static void compute2(String s) throws InvalidLastNameException 
    {
		 if (s.equals("null"))
			throw new InvalidLastNameException(s); 
    }
}