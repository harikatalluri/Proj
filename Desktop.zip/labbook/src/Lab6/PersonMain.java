package Lab6;
import java.lang.*;
import java.util.*;

public class PersonMain 
{
	public static void main(String[] args) 
	{
		PersonException p=new PersonException();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your first name: ");
		String firstName=sc.next();
		System.out.println("Enter your last name: ");
		String lastName=sc.next();
		System.out.println("Enter gender: ");
		String gender=sc.next();
		System.out.println("Enter phone number: ");
		long phone=sc.nextInt();
		try
		{
			p.compute1(firstName);
			p.compute2(lastName);
			System.out.println("\nPerson Details:");
			System.out.println("------------------");
			System.out.println("First name: "+firstName);
			System.out.println("Last name: "+lastName);
			System.out.println("Gender: "+gender);
			System.out.println("Phone number: "+phone);
		}
		catch(InvalidFirstNameException f)
		{
			System.out.println("caught "+f);
		}
		catch(InvalidLastNameException f)
		{
			System.out.println("caught "+f);
		}
	}

}
