package Lab6;

public class InvalidFirstNameException extends Exception
{				
	public String firstName;
	InvalidFirstNameException(String s)
	{
		firstName=s;
	}
}
