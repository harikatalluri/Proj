package Lab3;

import java.util.Scanner;

public class StringOperations 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string");
		String s=sc.next();
		System.out.println("Enter your choice\n 1.Add the string to itself\n 2.Replace odd positions with #\n 3.Remove duplicate characters in the string\n 4.Change odd characters to upper case");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1: System.out.println(s.concat(s));
				break;			
		case 2: String str="";
				for (int i=0; i < s.length(); i++)
				{
	        		if (i % 2 == 0)	
	        			str = str + "#";
	        		else
	        			str=str+s.charAt(i);
				}
				System.out.println(str);
				break;
			
		case 3: String s1="";
				for(int i=0;i<s.length();i++)
					for(int j=0;j<s1.length();j++)
						if(s.charAt(i)!=s1.charAt(j))
							s1 = s1 + s.charAt(i);
				System.out.println(s1);
				break;
			
		/*case 4: String str1="";
				for (int i=0; i < s.length(); i++)
				{
					if (i % 2 == 0)
					{
						String temp=null;
						temp=charAt(i);
						str = str + charAt(i).toUpperCase;
					}
					else
						str=str+s.charAt(i);
				}
				str.
				System.out.println(str);
				break; */
		}
	}

}
