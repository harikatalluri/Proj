import java.util.*;
public class Interview 
{
	public static void main(String[] args) 
	{
		Student stude1=new Student(1,"Harika","Btech");
		Student stude2=new Student(2,"Hari","BE");
		Student stude3=new Student(3,"Harini","BSc");
		Student stude4=new Student(4,"Har","Btech");
		List li=new ArrayList();
		li.add(stude1);
		li.add(stude2);
		li.add(stude3);
		li.add(stude4);
		for(Object ob:li)
			System.out.println(ob);
		Iterator it=li.iterator();
		if(it.hasNext())
			System.out.println(it.next());
	}

}
