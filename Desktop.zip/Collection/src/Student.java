public class Student 
{
	private int studentId;
	private String studentName;
	private String stream;
	
	Student()
	{
		
	}
	public Student(int studentId, String studentName, String stream) 
	{
		this.studentId = studentId;
		this.studentName = studentName;
		this.stream = stream;
	}
	
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	
	@Override
	public String toString() 
	{
		return "Student id : "+this.studentId
				+" Student name: "+this.studentName
				+" Stream: "+this.stream;
	}

}
