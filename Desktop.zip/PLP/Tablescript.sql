CREATE SEQUENCE java_registration_seq 
INCREMENT BY 1 
START WITH 1;

CREATE SEQUENCE java_transaction_seq 
INCREMENT BY 1 
START WITH 101;

CREATE SEQUENCE java_user_id_seq
INCREMENT BY 1
START WITH 1001;

CREATE TABLE java_UserTable(
userid VARCHAR2(4),
password VARCHAR2(7),
name VARCHAR2(20),
emailid VARCHAR2(25),
address VARCHAR2(50),
gender VARCHAR2(7),
phnnumber VARCHAR2(10),
librarian CHAR(1));

CREATE TABLE java_BooksInventory(
book_id VARCHAR2(4),
book_name VARCHAR2(30),
author1 VARCHAR2(25),
author2 VARCHAR2(25),
publisher VARCHAR2(25),
year_of_publication VARCHAR2(4),
no_of_copies NUMBER(5));

INSERT INTO java_BooksInventory VALUES('101','Let Us C++','Yashavant Kanetkar','B.C. Desai','H.Schild',2000,3);
INSERT INTO java_BooksInventory VALUES('102','Mastersing VC++','P.J Allen','Yashavant Kanetkar','B.C. Desai',2005,4);
INSERT INTO java_BooksInventory VALUES('103','JAVA Complete Reference','H.Schild','Yashavant Kanetkar','B.C. Desai',2004,0);
INSERT INTO java_BooksInventory VALUES('104','J2EE Complete Reference','Yashavant Kanetkar','H.Schild','B.C. Desai',2000,1);
INSERT INTO java_BooksInventory VALUES('105','Relational DBMS','B.C. Desai','Yashavant Kanetkar','H.Schild',2000,6);

CREATE TABLE java_BooksRegistration(
registration_id VARCHAR2(4),
book_id VARCHAR2(4),
user_id VARCHAR2(4),
registrationdate DATE);

CREATE TABLE java_BooksTransaction(
transaction_id varchar2(4), 
registration_id VARCHAR2(4),
issue_date DATE,
return_date DATE,
fine NUMBER(3));

