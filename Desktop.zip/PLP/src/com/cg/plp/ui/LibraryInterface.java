package com.cg.plp.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.bean.BookTransactionBean;
import com.cg.plp.bean.UserBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.service.ILibraryService;
import com.cg.plp.service.LibraryServiceImpl;

public class LibraryInterface 
{	
	public static void main(String[] args)
	{	
		String username=null;
		String emailid=null;
		String password=null;
		String mobileNumber=null;
		
		
		String id=null;
		String pwd=null;
		int choice=0;
		String bookid=null;
		String registrationid=null;
		String selection=null;
		int value=0;
		String request=null;
		
		int choose=0;
		
		UserBean userBean=new UserBean();
		BookBean bookBean=new BookBean();
		
		
		ILibraryService libraryServiceImpl=new LibraryServiceImpl();
		
		Scanner scan=new Scanner(System.in);
		Scanner sc=new Scanner(System.in).useDelimiter("\n");
		do
		{
			System.out.println("1. Registration\n2. Login\n3. Exit\nEnter your choice");
			choose=scan.nextInt();
			//Registration
			if(choose==1)
			{
				System.out.println("Enter the name");
				username=sc.next();
				System.out.println("enter the emailid");
				emailid=scan.next();
				System.out.println("Enter the password");
				password=scan.next();
				System.out.println("Enter the mobile number");
				mobileNumber=scan.next();
				
				/*do
				{
					System.out.println("Enter the name");
					username=sc.next();
				}while(libraryServiceImpl.isNameValid(username));
				userBean.setName(username);
				
				do
				{
					System.out.println("enter the emailid");
					emailid=scan.next();
				}while(libraryServiceImpl.isEmailValid(emailid));
				userBean.setEmailId(emailid);
				
				do
				{
					System.out.println("Enter the password");
					password=scan.next();
				}while(libraryServiceImpl.isPasswordValid(password));
				userBean.setPassword(password);
				
				do
				{
					System.out.println("Enter the mobile number");
					mobileNumber=scan.next();
				}while(libraryServiceImpl.IsPhnNumberValid(mobileNumber));
				userBean.setPhoneNum(mobileNumber);*/
				
				System.out.println("Enter the gender");
				String gender=scan.next();
				System.out.println("Enter the address");
				String address=sc.next();
				System.out.println("Are you a librarian(Y/N)");
				String librarian=scan.next();
				
				userBean.setName(username);
				userBean.setEmailId(emailid);
				userBean.setPassword(password);
				userBean.setPhoneNum(mobileNumber);
				userBean.setGender(gender);
				userBean.setAddress(address);
				userBean.setLibrarian(librarian);
				
				
				try 
				{
					int userid=libraryServiceImpl.registerUser(userBean);
					if(userid!=0)
					{
						System.out.println("Successfully registered...");
						System.out.println("Your user ID is:"+userid);
					}
					else
					{
						System.out.println("Registration Failed..");
					}
				} 
				catch (LibraryException e)
				{
					System.out.println(e.getMessage());
				}
			}
			//Login page
			else if(choose==2)
			{
				System.out.println("Login Here");
			
				try
				{
					boolean status;
					int num;
					do
						{					
							System.out.println("UserId: ");
							id=scan.next();
							System.out.println("Password: ");
							pwd=scan.next();
							num=libraryServiceImpl.isUserValid(id,pwd);
							if(num==0)
								status=true;
							else
								status=false;
						}while(status);
					
					//Librarian login starts 
					if(num==1)
					{
						System.out.println("Welcome "+libraryServiceImpl.getName(id));
						do
						{
							System.out.println("1. Add books\n2. Remove Books\n3.Manage Books taken by users\n4. exit");
							System.out.println("Enter your choice");
							int selected=scan.nextInt();
							
							if(selected==1)
							{
								System.out.println("Enter the book id");
								String bookId=scan.next();
								System.out.println("Enter the book name");
								String bookName=sc.next();
								System.out.println("Enter the name of first author");
								String author1=sc.next();
								System.out.println("Enter the name of the second author");
								String author2=sc.next();
								System.out.println("Enter the publisher");
								String publisher=sc.next();
								System.out.println("Enter the year of publication");
								String year=scan.next();
								System.out.println("Enter the number of copies");
								int copies=scan.nextInt();
								
								bookBean.setBookId(bookId);
								bookBean.setBookName(bookName);
								bookBean.setAuthor1(author1);
								bookBean.setAuthor2(author2);
								bookBean.setPublisher(publisher);
								bookBean.setYearOfPublication(year);
								bookBean.setNoOfCopies(copies);
								
								status=libraryServiceImpl.addBooks(bookBean);
								if(status)
								{
									System.out.println("Book is added successfully...");
								}
								else
									System.out.println("Failed to add the book");
							}
							
							else if(selected==2)
							{
								System.out.println("Enter the book id");
								String bookId=scan.next();
								status=libraryServiceImpl.removeBook(bookId);
								if(status)
								{
									System.out.println("The book is deleted successfully");
								}
								else
									System.out.println("Error in deleting the book");
							}
							
							else if(selected==3)
							{
								String transactionId;
								ArrayList<BookRegistrationBean> array=libraryServiceImpl.displayRequests();
								for(BookRegistrationBean b:array)
								{
									System.out.println(b.getRegistrationId());
									System.out.println(b.getBookId());
									System.out.println(b.getUserId());
									System.out.println(b.getRegistrationDate());
									
									registrationid=b.getRegistrationId();
									bookid=b.getBookId();
									System.out.println("Grant a book to the user???To grant press 1");
									int granting=scan.nextInt();
									if(granting==1)
									{
										transactionId=libraryServiceImpl.grantBook(registrationid,bookid);
										if(transactionId!=null)
										{
											System.out.println("Your book is issued and your transaction id is "+transactionId);
										}
										else
										{
											System.out.println("Requested book is out of copies");
										}
									}
									else
										continue;
								}
							}
							else if(selected==4)
							{
								System.out.println("Thank you..");
								System.exit(0);
							}
							else
							{
								System.out.println("You have entered an invalid choice..\nPlease enter the correct value");
							}
							
							System.out.println("Do you want to make another modification? Select Y or N");
							request=scan.next();
						}while(request.equals("Y") || request.equals("y"));	
					}
					//Student login starts here
					else if(num==2)
					{
						System.out.println("Welcome "+libraryServiceImpl.getName(id));
						
						do
							{
								System.out.println("1. Request a book\n2.Return a book\nEnter your choice");
								choice=scan.nextInt();
								if(choice==1)
								{
									System.out.println("Enter a book id:");
									bookid=scan.next();
								
									value=libraryServiceImpl.isBookAvailable(bookid);
									if(value==1)
									{
										System.out.println("Requested book is available");
										System.out.println("Do you want to place a request? "+ "Select Y to place a request. Otherwise select N");
										selection=scan.next();
										if(selection.equals("Y")||selection.equals("y"))
										{
											int registrationId=libraryServiceImpl.addRequest(id,bookid);
											if(registrationId==0)
											{
												System.out.println("Request for the book cannot be placed more than 1 time");
											}
											else
											{
												System.out.println("Request placed and your registration id is "+registrationId);
											}
										}
										else
										{
											System.out.println("request is not placed");
										}
									}
									else if(value==2)
									{
										System.out.println("Requested book is out of copies");
									}
									else if(value==3)
									{
										System.out.println("Entered bookid doesnot match with any of the books");
										
									}									
								}
								// to return a book
								else if(choice==2)
								{
									BookTransactionBean bean=new BookTransactionBean();
									
									System.out.println("Enter the transaction id");
									String transactionId=scan.next();
									System.out.println("Enter the bookid");
									bookid=scan.next();
//									
//									bean.setTransactionId(tranid);
//									bean.setBookId(bookid);
//									bean.setUserId(id);
									
									int fine=libraryServiceImpl.returnBook(transactionId,bookid);
									System.out.println("Your book is returned successfully and your fine is "+fine);
								}
								System.out.println("Do you want to logout? Select Y or N");
								request=scan.next();
							}while(request.equals("N") || request.equals("n"));	
					}	
				} 
				catch (LibraryException e) 
				{
					System.out.println(e.getMessage());
				}	
			}
			else if(choose==3)
			{
				System.out.println("thank you");
				System.exit(0);
			}
			
			System.out.println("Go to Home page? Select Y or N");
			request=scan.next();
		}while(request.equals("Y") || request.equals("y"));	
		
		
	scan.close();
	}
}
