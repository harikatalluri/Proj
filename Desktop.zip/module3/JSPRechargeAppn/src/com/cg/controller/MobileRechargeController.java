package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.MobileBean;
import com.cg.exception.MobileException;
import com.cg.service.IMobileService;
import com.cg.service.MobileServiceImpl;

@WebServlet("/MobileRechargeController")
public class MobileRechargeController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	long rechargeId=0;
	String planName=null;
	String mobileNumber=null;
	boolean status=false;
	
	IMobileService mobileServiceImpl=new MobileServiceImpl();
	MobileBean mobileBean=new MobileBean();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		String option=request.getParameter("option");
		
		if(option!= null && option.equals("getRechargeId"))
		{
			try 
			{
				rechargeId=mobileServiceImpl.getRechargeId();
				
				LocalDate date=LocalDate.now();
				
				request.setAttribute("now",date);
				request.setAttribute("rechargeId",rechargeId);
				
				ServletContext context=getServletContext();
				RequestDispatcher rd=context.getRequestDispatcher("/RechargeForm.jsp");
				rd.forward(request,response);
			} 
			catch (MobileException e) 
			{
				out.println(e.getMessage());
			}
		}
		
		
		if(option!= null && option.equals("Recharge"))
		{
			planName=request.getParameter("plan");
			mobileNumber=request.getParameter("mobileNum");
			
			mobileBean.setRechargeId(rechargeId);
			mobileBean.setPlanName(planName);
			mobileBean.setMobileNumber(mobileNumber);
			
			try 
			{
				status=mobileServiceImpl.storeRechargeDetails(mobileBean);
				if(status)
					out.println("<h1>Recharge successful</h2>");
				else
					out.println("<h2>Recharge failed</h2>");
			} 
			catch (MobileException e) 
			{
				out.println(e.getMessage());
			}
		}
		
		
		if(option!= null && option.equals("viewRechargeDetails"))
		{
			try 
			{
				
			} 
			catch (MobileException e) 
			{
				out.println(e.getMessage());
			}
		}
	}
}
