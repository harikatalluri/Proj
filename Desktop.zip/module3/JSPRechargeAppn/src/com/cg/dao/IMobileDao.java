package com.cg.dao;

import com.cg.bean.MobileBean;
import com.cg.exception.MobileException;

public interface IMobileDao 
{
	public long getRechargeId() throws MobileException;
	public boolean storeRechargeDetails(MobileBean mobileBean) throws MobileException;
}
