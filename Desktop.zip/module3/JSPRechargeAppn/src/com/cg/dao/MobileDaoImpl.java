package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.util.MobileDBConnection;
import com.cg.bean.MobileBean;
import com.cg.exception.MobileException;

public class MobileDaoImpl implements IMobileDao
{
	MobileBean mobileBean=new MobileBean();
	
	Connection connection=MobileDBConnection.getConnection();
	PreparedStatement preparedStatement=null;
	PreparedStatement preparedStatement1=null;
	ResultSet resultSet=null;
	
	public long getRechargeId() throws MobileException
	{
		long rechargeId=0;
		
		try 
		{
			preparedStatement=connection.prepareStatement("SELECT seq_bill_num.NEXTVAL FROM DUAL");
			preparedStatement.executeQuery();
			preparedStatement=connection.prepareStatement("SELECT seq_bill_num.CURRVAL FROM DUAL");
			resultSet=preparedStatement.executeQuery();

			while(resultSet.next())
			{
				rechargeId=resultSet.getInt(1);
			}
		}
		catch (SQLException e) 
		{
			throw new MobileException(e.getMessage());
		}
		return rechargeId;
	}
	
	public boolean storeRechargeDetails(MobileBean mobileBean) throws MobileException
	{
		boolean status=false;
		int queryResult=0;

		try 
		{
			preparedStatement=connection.prepareStatement("INSERT INTO MobilePlan VALUES(?,?,SYSDATE,?)");
			preparedStatement.setLong(1,mobileBean.getRechargeId());
			preparedStatement.setString(2,mobileBean.getPlanName());
			preparedStatement.setString(3,mobileBean.getMobileNumber());
			queryResult=preparedStatement.executeUpdate();

			if(queryResult>0)
				status=true;
			else
				status=false;
		}
		catch (SQLException e) 
		{
			throw new MobileException(e.getMessage());
		}
		return status;
	}
}
