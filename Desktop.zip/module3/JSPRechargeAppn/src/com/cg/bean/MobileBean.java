package com.cg.bean;

public class MobileBean 
{
	private long rechargeId=0;
	private String planName=null;
	private String mobileNumber=null;
	
	public long getRechargeId() {
		return rechargeId;
	}
	public void setRechargeId(long rechargeId) {
		this.rechargeId = rechargeId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
}
