package com.cg.service;

import com.cg.bean.MobileBean;
import com.cg.dao.IMobileDao;
import com.cg.dao.MobileDaoImpl;
import com.cg.exception.MobileException;

public class MobileServiceImpl implements IMobileService 
{
	IMobileDao mobileDaoImpl=new MobileDaoImpl();
	
	public long getRechargeId() throws MobileException
	{
		return mobileDaoImpl.getRechargeId();
	}
	
	public boolean storeRechargeDetails(MobileBean mobileBean) throws MobileException
	{
		return mobileDaoImpl.storeRechargeDetails(mobileBean);
	}

}
