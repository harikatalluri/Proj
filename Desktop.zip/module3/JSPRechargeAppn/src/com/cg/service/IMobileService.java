package com.cg.service;

import com.cg.bean.MobileBean;
import com.cg.exception.MobileException;

public interface IMobileService 
{
	public long getRechargeId() throws MobileException;
	public boolean storeRechargeDetails(MobileBean mobileBean) throws MobileException;
}
