package com.cg.exception;

public class MobileException extends Exception
{
	private static final long serialVersionUID = 1L;

	public MobileException(String message) 
	{
		super(message);
	}
}
