CREATE TABLE MobilePlan(
recharge_id NUMBER(6) PRIMARY KEY,
plan_name VARCHAR2(10) NOT NULL,
recharge_date DATE,
mobile_number VARCHAR2(10)
);

CREATE SEQUENCE seq_recharge_id START WITH 101;