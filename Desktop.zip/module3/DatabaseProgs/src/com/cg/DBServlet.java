package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//sqlplus  trg1102/training1102@10.219.34.3:1521/orcl

@WebServlet("/DBServlet")
public class DBServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	Connection con;
	String url = "jdbc:oracle:thin:@10.219.34.3:1521:orcl";

	public void init() throws ServletException {
		try {
			// URL Pattern, username, password can be obtained from Servlet init parameters also
			  Class.forName("oracle.jdbc.driver.OracleDriver"); 
			 con = DriverManager.getConnection(url,"trg1102","training1102");
		} catch (Exception e) {
			System.out.println("Database connect failed (init)");
			System.out.println(e.toString());
			return;
		}
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from dept");
			while(rs.next()){
				pw.println(rs.getInt("DEPT_CODE") + "<br>");
				pw.println(rs.getString("DEPT_NAME") + "<br>");
			}
			con.close();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

	}

}
