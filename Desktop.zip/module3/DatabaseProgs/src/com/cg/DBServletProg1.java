package com.cg;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

@WebServlet("/DBServletProg1")
public class DBServletProg1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		InitialContext ic;
		try
		{
			ic=new InitialContext();
			DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			Statement st=con.createStatement();
			ResultSet rs = st.executeQuery("select * from dept");
			while(rs.next()){
				out.println(rs.getInt("DEPT_CODE") + "<br>");
				out.println(rs.getString("DEPT_NAME") + "<br>");
			}
			con.close();
		}
		catch(NamingException e)
		{
			System.out.println(e.getMessage());
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}


}
