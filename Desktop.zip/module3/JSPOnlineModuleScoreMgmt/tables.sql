CREATE TABLE trainees(
trainee_id NUMBER PRIMARY KEY,
trainee_name VARCHAR2(30)
);

INSERT INTO trainees VALUES(898983,'Tina');
INSERT INTO trainees VALUES(898984,'Vina');
INSERT INTO trainees VALUES(898985,'Gita');
INSERT INTO trainees VALUES(898986,'Rita');
INSERT INTO trainees VALUES(898987,'Sita');
INSERT INTO trainees VALUES(898988,'Mala');

CREATE TABLE AssessmentScore(
trainee_id NUMBER REFERENCES trainees(trainee_id),
module_name VARCHAR2(10),
mpt NUMBER,
mtt NUMBER,
ass_marks NUMBER,
total NUMBER,
grade NUMBER
);