package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.TraineeBean;
import com.cg.util.DBConnection;
import com.cg.exception.ModuleScoreException;

public class ModuleDAO implements IModuleDAO 
{
	Connection connection=DBConnection.getConnection();
	PreparedStatement preparedStatement=null;
	PreparedStatement preparedStatement1=null;
	ResultSet resultSet=null;
	
	@Override
	public ArrayList<TraineeBean> getDropDownId() throws ModuleScoreException
	{
		
		ArrayList<TraineeBean> idList=new ArrayList<TraineeBean>();
		long traineeId=0;
		try
		{
			preparedStatement=connection.prepareStatement("SELECT trainee_id FROM trainees");
			resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next())
			{
				TraineeBean traineeBean=new TraineeBean();
				traineeId=resultSet.getLong("trainee_id");
				traineeBean.setTraineeId(traineeId);
				idList.add(traineeBean);
			}
		}
		catch(SQLException e)
		{
			throw new ModuleScoreException(e.getMessage());
		}
		
		return idList;
	}
	
	
	//------------------------ 1.Online Score Management System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addTraineeDetails(TraineeBean traineeBean)
	 - Input Parameters	:	TraineeBean 
	 - Return Type		:	boolean
	 - Throws			:  	ModuleScoreException
	 - Author			:	Harika
	 - Creation Date	:	02/07/2018
	 - Description		:	Adding trainee details to database
	 ********************************************************************************************************/
	@Override
	public boolean addTraineeDetails(TraineeBean traineeBean) throws ModuleScoreException
	{
		boolean status=false;
		
		long traineeId=traineeBean.getTraineeId();
		String moduleName=traineeBean.getModuleName();
		int mptMarks=traineeBean.getMptMarks();
		int mttMarks=traineeBean.getMttMarks();
		int assignmentMarks=traineeBean.getAssignmentMarks();
		int total=traineeBean.getTotal();
		int grade=traineeBean.getGrade();
		
		try
		{
			preparedStatement=connection.prepareStatement("SELECT trainee_id,module_name FROM AssessmentScore");
			resultSet=preparedStatement.executeQuery();
			
			ArrayList<TraineeBean> traineeList=new ArrayList<TraineeBean>();
			
			if(resultSet.next())
			{
				do
				{
				TraineeBean trainee=new TraineeBean();
				trainee.setTraineeId(resultSet.getLong("trainee_id"));
				trainee.setModuleName(resultSet.getString("module_name"));
				
				traineeList.add(trainee);
				}while(resultSet.next());
				
				for(TraineeBean singleTrainee:traineeList)
				{
					String tempModuleName=singleTrainee.getModuleName();
					if(singleTrainee.getTraineeId()==traineeId && tempModuleName.equals("moduleName"))
					{
						status=false;
					}
					else
					{
						status=true;
						preparedStatement=connection.prepareStatement
								("INSERT INTO AssessmentScore VALUES(?,?,?,?,?,?,?)");
						preparedStatement.setLong(1,traineeId);
						preparedStatement.setString(2,moduleName);
						preparedStatement.setInt(3,mptMarks);
						preparedStatement.setInt(4,mttMarks);
						preparedStatement.setInt(5,assignmentMarks);
						preparedStatement.setInt(6,total);
						preparedStatement.setInt(7,grade);
						preparedStatement.executeUpdate();
						break;
					}
				}
			}
			
			else
			{
				status=true;
				preparedStatement=connection.prepareStatement
						("INSERT INTO AssessmentScore VALUES(?,?,?,?,?,?,?)");
				preparedStatement.setLong(1,traineeId);
				preparedStatement.setString(2,moduleName);
				preparedStatement.setInt(3,mptMarks);
				preparedStatement.setInt(4,mttMarks);
				preparedStatement.setInt(5,assignmentMarks);
				preparedStatement.setInt(6,total);
				preparedStatement.setInt(7,grade);
				preparedStatement.executeUpdate();
			}
		}
		catch(SQLException e)
		{
			throw new ModuleScoreException(e.getMessage());
		}
		return status;
	}

}
