package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.TraineeBean;
import com.cg.exception.ModuleScoreException;

public interface IModuleDAO 
{
	public ArrayList<TraineeBean> getDropDownId() throws ModuleScoreException;
	public boolean addTraineeDetails(TraineeBean traineeBean) throws ModuleScoreException;
}
