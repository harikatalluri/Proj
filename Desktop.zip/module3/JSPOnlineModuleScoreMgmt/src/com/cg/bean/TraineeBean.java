package com.cg.bean;

public class TraineeBean 
{
	private long traineeId=0;
	private String moduleName=null;
	private int mptMarks=0;
	private int mttMarks=0;
	private int assignmentMarks=0;
	private int total=0;
	private int grade=0;
	
	public long getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(long traineeId) {
		this.traineeId = traineeId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public int getMptMarks() {
		return mptMarks;
	}
	public void setMptMarks(int mptMarks) {
		this.mptMarks = mptMarks;
	}
	public int getMttMarks() {
		return mttMarks;
	}
	public void setMttMarks(int mttMarks) {
		this.mttMarks = mttMarks;
	}
	public int getAssignmentMarks() {
		return assignmentMarks;
	}
	public void setAssignmentMarks(int assignmentMarks) {
		this.assignmentMarks = assignmentMarks;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
}
