package com.cg.exception;

public class ModuleScoreException extends Exception
{
	private static final long serialVersionUID = 1L;

	public ModuleScoreException(String message) 
	{
		super(message);
	}
}
