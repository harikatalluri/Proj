package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.TraineeBean;
import com.cg.exception.ModuleScoreException;
import com.cg.service.IModuleService;
import com.cg.service.ModuleService;

@WebServlet("/ModuleController")
public class ModuleController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	IModuleService moduleService=new ModuleService();
	TraineeBean traineeBean=new TraineeBean();
	
	long traineeId=0;
	String moduleName=null;
	int mptMarks=0;
	int mttMarks=0;
	int assignmentMarks=0;
	int total=0;
	int grade=0;
	boolean status=false;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		
		String option=request.getParameter("option");
		
		if(option!=null && option.equals("getDropDown"))
		{
			ArrayList<TraineeBean> idList=new ArrayList<TraineeBean>();
			try 
			{
				idList=moduleService.getDropDownId();
			} 
			catch (ModuleScoreException e) 
			{
				out.println(e.getMessage());
			}
			
			request.setAttribute("idList",idList);
			
			ServletContext context=getServletContext();
			RequestDispatcher rd=context.getRequestDispatcher("/AddAssessment.jsp");
			rd.forward(request,response);
		}
		
		if(option!=null && option.equals("Submit"))
		{
			traineeId=Long.parseLong(request.getParameter("traineeId"));
			moduleName=request.getParameter("moduleName");
			mptMarks=Integer.parseInt(request.getParameter("mpt"));
			mttMarks=Integer.parseInt(request.getParameter("mtt"));
			assignmentMarks=Integer.parseInt(request.getParameter("assignment"));
			
			total=moduleService.calculateTotal(mptMarks,mttMarks,assignmentMarks);
			grade=moduleService.calcutateGrade(total);
			
			traineeBean.setTraineeId(traineeId);
			traineeBean.setModuleName(moduleName);
			traineeBean.setMptMarks(mptMarks);
			traineeBean.setMttMarks(mttMarks);
			traineeBean.setAssignmentMarks(assignmentMarks);
			traineeBean.setTotal(total);
			traineeBean.setGrade(grade);
			
			try
			{
				status=moduleService.addTraineeDetails(traineeBean);
				if(status)
				{
					request.setAttribute("traineeBean",traineeBean);
					
					ServletContext context=getServletContext();
					RequestDispatcher rd=context.getRequestDispatcher("/ModuleScore.jsp");
					rd.forward(request,response);
				}
				else
				{
					response.sendRedirect("AddAssessment.jsp");
				}
			}
			catch(ModuleScoreException e)
			{
				out.println(e.getMessage());
			}
		}
	}

}
