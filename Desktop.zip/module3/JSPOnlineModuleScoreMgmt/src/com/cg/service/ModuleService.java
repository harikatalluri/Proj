package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.TraineeBean;
import com.cg.dao.IModuleDAO;
import com.cg.dao.ModuleDAO;
import com.cg.exception.ModuleScoreException;

public class ModuleService implements IModuleService
{
	IModuleDAO moduleDAO=new ModuleDAO(); 
	
	//------------------------ 1.Online Score Management System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	calculateTotal(int mptMarks,int mttMarks,int assignmentMarks)
		 - Input Parameters	:	int,int,int
		 - Return Type		:	int
		 - Throws			:  	ModuleScoreException
		 - Author			:	Harika
		 - Creation Date	:	02/07/2018
		 - Description		:	Calculating total marks
		 ********************************************************************************************************/
	@Override
	public int calculateTotal(int mptMarks,int mttMarks,int assignmentMarks)
	{
		int total=0;
		total=((mptMarks*70)/100)+((mttMarks*15)/100)+((assignmentMarks*15)/100);
		return total;
	}
	
	
	//------------------------ 1.Online Score Management System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	calcutateGrade(int total)
		 - Input Parameters	:	int 
		 - Return Type		:	int
		 - Throws			:  	ModuleScoreException
		 - Author			:	Harika
		 - Creation Date	:	02/07/2018
		 - Description		:	Calculating grade
		 ********************************************************************************************************/
	@Override
	public int calcutateGrade(int total)
	{
		int grade=0;
		if(total>=90 && total<=100)
			grade=5;
		else if(total>=80 && total<90)
			grade=4;
		else if(total>=70 && total<80)
			grade=3;
		else if(total>=60 && total<70)
			grade=2;
		else if(total>=50 && total<60)
			grade=1;
		else
			grade=0;
		return grade;
	}
	
	@Override
	public ArrayList<TraineeBean> getDropDownId() throws ModuleScoreException
	{
		return moduleDAO.getDropDownId();
	}
	
	@Override
	public boolean addTraineeDetails(TraineeBean traineeBean) throws ModuleScoreException
	{
		return moduleDAO.addTraineeDetails(traineeBean);
	}
}
