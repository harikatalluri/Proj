package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.TraineeBean;
import com.cg.exception.ModuleScoreException;

public interface IModuleService 
{
	public int calculateTotal(int mptMarks,int mttMarks,int assignmentMarks);
	public int calcutateGrade(int total);
	public ArrayList<TraineeBean> getDropDownId() throws ModuleScoreException;
	public boolean addTraineeDetails(TraineeBean traineeBean) throws ModuleScoreException;
}
