package com.cg.bean;

public class CustomerBean 
{
	private String userId;
	private String password;
	private long billNumber;
	private long consumerNum;
	private float lastRead;
	private float currentRead;
	float units;
	float netAmount;
	private String consumerName;
	private String consumerAddress;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getBillNumber() {
		return billNumber;
	}
	public void setBillNumber(long billNumber) {
		this.billNumber = billNumber;
	}
	public long getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(long consumerNum) {
		this.consumerNum = consumerNum;
	}
	public float getLastRead() {
		return lastRead;
	}
	public void setLastRead(float lastRead) {
		this.lastRead = lastRead;
	}
	public float getCurrentRead() {
		return currentRead;
	}
	public void setCurrentRead(float currentRead) {
		this.currentRead = currentRead;
	}
	public float getUnits() {
		return units;
	}
	public void setUnits(float units) {
		this.units = units;
	}
	public float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}
	public String getConsumerName() {
		return consumerName;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}
	public String getConsumerAddress() {
		return consumerAddress;
	}
	public void setConsumerAddress(String consumerAddress) {
		this.consumerAddress = consumerAddress;
	}	
}
