package com.cg.service;

import com.cg.bean.CustomerBean;
import com.cg.exception.CustomerException;

public interface ICustomerService
{
	public long insertBillDetails(CustomerBean customerBean) throws CustomerException;
	public CustomerBean getBillDetails(long billNumber) throws CustomerException;
}
