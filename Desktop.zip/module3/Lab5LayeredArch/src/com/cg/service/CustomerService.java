package com.cg.service;

import com.cg.bean.CustomerBean;
import com.cg.dao.CustomerDao;
import com.cg.dao.ICustomerDao;
import com.cg.exception.CustomerException;

public class CustomerService implements ICustomerService
{
	ICustomerDao customerDao=new CustomerDao();
	
	public long insertBillDetails(CustomerBean customerBean) throws CustomerException
	{
		return customerDao.insertBillDetails(customerBean);
	}
	
	public CustomerBean getBillDetails(long billNumber) throws CustomerException
	{
		return customerDao.getBillDetails(billNumber);
	}

}
