package com.cg.dao;

import com.cg.bean.CustomerBean;
import com.cg.exception.CustomerException;

public interface ICustomerDao
{
	public long insertBillDetails(CustomerBean customerBean) throws CustomerException;
	public CustomerBean getBillDetails(long billNumber) throws CustomerException;
}