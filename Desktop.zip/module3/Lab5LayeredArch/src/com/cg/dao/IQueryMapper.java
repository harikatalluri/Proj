package com.cg.dao;

public interface IQueryMapper 
{
	public static final String INSERTQUERY="INSERT INTO BillDetails VALUES(seq_bill_num.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String CURRENTSEQUENCE="SELECT seq_bill_num.CURRVAL FROM DUAL";
	public static final String SELECTQUERY="SELECT consumer_num,unitConsumed,netAmount FROM billDetails WHERE bill_num=?";
}
