package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dbutil.DBConnection;
import com.cg.exception.CustomerException;
import com.cg.bean.CustomerBean;


public class CustomerDao implements ICustomerDao
{
	
	public long insertBillDetails(CustomerBean customerBean) throws CustomerException
	{
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet=null;
		long billNumber=0;
		int queryResult=0;
		
		try 
		{
			preparedStatement=connection.prepareStatement(IQueryMapper.INSERTQUERY);
			preparedStatement.setLong(1,customerBean.getConsumerNum());
			preparedStatement.setFloat(2,customerBean.getCurrentRead());
			preparedStatement.setFloat(3,customerBean.getUnits());
			preparedStatement.setFloat(4,customerBean.getNetAmount());
			queryResult=preparedStatement.executeUpdate();
			
			if(queryResult>0)
			{
				preparedStatement1 = connection.prepareStatement(IQueryMapper.CURRENTSEQUENCE);
				resultSet=preparedStatement1.executeQuery();
	
				if(resultSet.next())
				{
					billNumber=resultSet.getInt(1);
					customerBean.setBillNumber(billNumber);
				}
			}
		}
		catch(SQLException e) 
		{
			throw new CustomerException("No data found for entered id");
		}
		return billNumber;
	}
	
	public CustomerBean getBillDetails(long billNumber) throws CustomerException
	{
		CustomerBean customerBean=new CustomerBean();
		
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet1=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(IQueryMapper.SELECTQUERY);
			preparedStatement.setLong(1,billNumber);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
					customerBean.setConsumerNum(resultSet.getLong("consumer_num"));
					customerBean.setUnits(resultSet.getFloat("unitConsumed"));
					customerBean.setNetAmount(resultSet.getFloat("netAmount"));
			}
			preparedStatement1=connection.prepareStatement
					("SELECT consumer_name FROM consumers WHERE consumer_num=?");
			preparedStatement1.setLong(1,customerBean.getConsumerNum());
			resultSet1=preparedStatement1.executeQuery();
			while(resultSet1.next())
			{
					customerBean.setConsumerName(resultSet1.getString("consumer_name"));
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new CustomerException("Caught: "+e.getMessage());
		}
		return customerBean;
	}

}
