package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.CustomerBean;
import com.cg.exception.CustomerException;
import com.cg.service.CustomerService;
import com.cg.service.ICustomerService;

@WebServlet("/CustomerController")
public class CustomerController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	float units;
	float netAmount;
	int fixedCharge=100;
	long billNumber=0;
	
	ICustomerService customerService=new CustomerService();
	CustomerBean customerBean=new CustomerBean();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{	
		PrintWriter out=response.getWriter();
		
		String option=request.getParameter("sbutton");
		
		if(option!= null && option.equals("submit"))
		{
			String userid=request.getParameter("uid");
			String pswd=request.getParameter("pwd");
			if(isValidCustomer(userid,pswd))
			{
				customerBean.setUserId("userid");
				customerBean.setPassword("pswd");
				request.getRequestDispatcher("./userinfo.html").forward(request,response);
			}
			else
			{
				response.sendRedirect("login.html");
			}
		}
		
		else if(option!= null && option.equals("Calculate Bill"))
		{
			long consumerNumber=Long.parseLong(request.getParameter("consumerNumber"));
			float lastMonthRead=Float.parseFloat(request.getParameter("lastRead"));
			float currentMonthRead=Float.parseFloat(request.getParameter("currentRead"));
			
			if(currentMonthRead>lastMonthRead)
			{	
				float netAmount=calculateNetAmount(currentMonthRead,lastMonthRead);
				
				customerBean.setConsumerNum(consumerNumber);
				customerBean.setLastRead(lastMonthRead);
				customerBean.setCurrentRead(currentMonthRead);
				customerBean.setUnits(units);
				customerBean.setNetAmount(netAmount);
				
				try 
				{
					billNumber=customerService.insertBillDetails(customerBean);
					
					customerBean=customerService.getBillDetails(billNumber);
					
					out.println("<h3> Welcome "+customerBean.getConsumerName());
					out.println("<br> <h1> Electricity Bill for Consumer Number - "+customerBean.getConsumerNum()+" is ");
					out.println("<h3> Unit Consumed:: "+customerBean.getUnits());
					out.println("<h3> Net Amount:: "+customerBean.getNetAmount());
				}
				catch (CustomerException e) 
				{
					out.println(e.getMessage());
				}
			}
			else
			{
				response.sendRedirect("userinfo.html");
			}
		}
	}
	
	public boolean isValidCustomer(String userid,String pswd)
	{
		if(userid.equals("harika") && pswd.equals("abc123"))
		{
			return true;
		} 
		else 
		{
			return false;	
		}
	}
	
	public float calculateNetAmount(float currentMonthRead,float lastMonthRead)
	{
		units=currentMonthRead-lastMonthRead;
		netAmount=(float) ((units*1.15)+fixedCharge);
		return netAmount;
	}
}
