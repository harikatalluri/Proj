package com.cg;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Mobile;

@WebServlet("/MobileServlet")
public class MobileServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String mobileName = request.getParameter("mname");
		String mobileBrand = request.getParameter("mbrand");
		double mobilePrice = Double.parseDouble(request.getParameter("mprice"));

		Mobile mobile=new Mobile();
		mobile.setmName(mobileName);
		mobile.setmBrand(mobileBrand);
		mobile.setmPrice(mobilePrice);
		
		request.setAttribute("mob",mobile);

		request.setAttribute("mobileCompanyName", "BigC");
		request.setAttribute("mobileCompanyEmail", "feedback@bigc.com");
		RequestDispatcher rd= getServletContext().getRequestDispatcher("/DisplayMobileServlet");
		rd.forward(request, response);
	}

}
