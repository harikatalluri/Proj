package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
//import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.cg.bean.Mobile;

@WebServlet("/DisplayMobileServlet")
public class DisplayMobileServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//ServletOutputStream os = response.getOutputStream();
		PrintWriter os=response.getWriter();
		
		Mobile mob1 = (Mobile) request.getAttribute("mob");
		String shopName = (String) request.getAttribute("mobileCompanyName");
		String eMail = (String)request.getAttribute("mobileCompanyEmail");
		
		try 
		{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			PreparedStatement pst = con.prepareStatement("INSERT INTO mobile VALUES(?,?,?,?,?)");
			pst.setString(1,mob1.getmName());
			pst.setString(2,mob1.getmBrand());
			pst.setDouble(3,mob1.getmPrice());
			pst.setString(4,shopName);
			pst.setString(5,eMail);

			pst.executeUpdate();
			
			pst.close();
			con.close();
		} 
		catch(NamingException e)
		{
			System.out.println(e.getMessage());
		}
		catch (SQLException e1) 
		{
			os.println(e1.getMessage());
		}
		
		os.println("\nMobile Data entered is:<BR>");
		os.println("Product Name : "+ mob1.getmName()
					+"<br>Price : " + mob1.getmBrand()
					+"<br>Quantity : " + mob1.getmPrice());
		os.println("<br>Shop Name : " + shopName);
		os.println("<br>Mail : " + eMail);
	}

}
