package com.cg.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.*;

public class ActionController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{

		String id=request.getParameter("eid");
		int eid=Integer.parseInt(id);
		
		String enm=request.getParameter("enm");
		
		String sal=request.getParameter("esl");
		double esl=Double.parseDouble(sal);
		
		EmployeeBean employee=new EmployeeBean();
		
		employee.setEid(eid);
		employee.setEnm(enm);
		employee.setEsl(esl);
		
		getServletContext().setAttribute("employee",employee);
		
		response.sendRedirect("output.jsp");
	}

}
