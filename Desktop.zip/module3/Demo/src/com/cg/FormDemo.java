package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/FormDemo")
public class FormDemo extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("uname");
		String gender=request.getParameter("gender");
		String qualification=request.getParameter("qualification");
		
		out.println("Name is : "+name);
		out.println("<br>Gender is : "+gender);
		out.println("<br>Qualification is : "+qualification);
		
		String[] proofs=request.getParameterValues("proofs");
		out.println("<br>Values checked for proofs are:<br>");
		if(proofs!=null)
		{
			for(String proof:proofs)
				out.println(proof + "<br>");
		}
		
		String[] hobbies = request.getParameterValues(("hobbies"));
		out.println("Values entered for hobbies are::<BR>");
		if(hobbies != null){
			for (String hobby : hobbies) {
				out.println(hobby + "<br>");
			}
		}
		
		String queryString=request.getQueryString();
		out.println("<br> Query string: "+queryString);
		
		String requestURI=request.getRequestURI();
		out.println("<br> URI: "+requestURI);
		
		out.println("<br> Input parameters are");
		Enumeration<String> inputParameters=request.getParameterNames();
		while(inputParameters.hasMoreElements())
		{
			String param=inputParameters.nextElement();
			out.println("<br>"+param);
		}
	}
}
