package com.cg;

import java.io.IOException;
import java.util.Random;
import java.util.Vector;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class SiteSelector
 */
@WebServlet("/SiteSelector")
public class SiteSelector extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    Vector sites = new Vector();
	Random random = new Random();
	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		sites.addElement("http://www.google.com");
		sites.addElement("http://docs.oracle.com/javaee/6/tutorial/doc/bnafd.html");
		sites.addElement("http://www.oracle.com/technetwork/java/javase/8-whats-new-2157071.html");
		sites.addElement("http://en.wikipedia.org/wiki/Web_container");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");

		int siteIndex = Math.abs(random.nextInt()) % sites.size();
		String site = (String) sites.elementAt(siteIndex);
		response.sendRedirect(site);
	}

}
