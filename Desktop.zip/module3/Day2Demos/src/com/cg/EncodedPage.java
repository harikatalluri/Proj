package com.cg;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.zip.GZIPOutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EncodedPage")
public class EncodedPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		String encode = request.getHeader("Accept-Encoding");
		PrintWriter out;
		String title;
		if ((encode != null) && (encode.indexOf("gzip") != -1)){
			title = "Page Encoded with GZip";
			OutputStream out1 = response.getOutputStream();
			out = new PrintWriter(new GZIPOutputStream(out1), false);
			response.setHeader("Content-Encoding", "gzip");
		} else {
			title = "Unencoded Page";
			out = response.getWriter();
		}
		out.println("<HTML><HEAD><TITLE>" + title + "</TITLE>"
				+ "<BODY BGCOLOR=\"#FDF5E6\">\n" + "<H1 ALIGN=CENTER>" + title
				+ "</H1>\n");
		String line = "Browsers that support Encoding feature indicate that "
				+ "they do so by setting the Accept-Encoding request header";
		for (int i = 0; i < 10000; i++) {
			out.println(line);
		}
		out.println("</BODY></HTML>");
		out.close();
	}

}
