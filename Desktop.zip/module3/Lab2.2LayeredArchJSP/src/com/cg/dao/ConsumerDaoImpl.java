package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.bean.ConsumerBean;
import com.cg.bean.ConsumerBillBean;
import com.cg.dbutil.DBConnection;
import com.cg.exception.ConsumerException;

public class ConsumerDaoImpl implements IConsumerDao
{
	Connection connection=DBConnection.getConnection();
	PreparedStatement preparedStatement=null;
	PreparedStatement preparedStatement1=null;
	ResultSet resultSet=null;
	
	//------------------------ 1.Electricity Bill --------------------------
			/*******************************************************************************************************
			 - Function Name	:	showTable()
			 - Input Parameters	:	
			 - Return Type		:	List
			 - Throws			:  	Consumerexception
			 - Author			:	Harika
			 - Creation Date	:	30/06/2018
			 - Description		:	displaying consumer list
			 ********************************************************************************************************/
	@Override
	public ArrayList<ConsumerBean> showTable() throws ConsumerException
	{
		ArrayList<ConsumerBean> consumerList=new ArrayList<ConsumerBean>();
	
		try
		{
			preparedStatement=connection.prepareStatement(IQueryMapper.SELECT_SHOWTABLE_QUERY);
			resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next())
			{
				ConsumerBean consumerBean=new ConsumerBean();
				consumerBean.setConsumerNum(resultSet.getLong("consumer_num"));
				consumerBean.setConsumerName(resultSet.getString("consumer_name"));
				consumerBean.setConsumerAddress(resultSet.getString("address"));
				
				consumerList.add(consumerBean);
			}
		}
		catch(SQLException e)
		{
			throw new ConsumerException(e.getMessage());
		}
		return consumerList;
	}
	
	@Override
	public ConsumerBean getConsumerDetails(long consumerNumber) throws ConsumerException
	{
		ConsumerBean consumerBean=null;
		try
		{
			preparedStatement=connection.prepareStatement(IQueryMapper.SELECT_GETCONSUMERDETAILS_QUERY);
			preparedStatement.setLong(1,consumerNumber);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				if(resultSet.getString("consumer_name")!=null)
				{
					consumerBean=new ConsumerBean();
					consumerBean.setConsumerNum(resultSet.getLong("consumer_num"));
					consumerBean.setConsumerName(resultSet.getString("consumer_name"));
					consumerBean.setConsumerAddress(resultSet.getString("address"));
				}
			}
		}
		catch(SQLException e)
		{
			throw new ConsumerException(e.getMessage());
		}
		return consumerBean;
	}
	
	@Override
	public ArrayList<ConsumerBillBean> getBillDetails(long consumerNumber) throws ConsumerException
	{
		ArrayList<ConsumerBillBean> consumerBillList=new ArrayList<ConsumerBillBean>();
		try
		{
			preparedStatement=connection.prepareStatement(IQueryMapper.SELECT_GETBILLDETAILS_QUERY);
			preparedStatement.setLong(1,consumerNumber);
			resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next())
			{
				ConsumerBillBean consumerBillBean=new ConsumerBillBean();
				//consumerBillBean.setConsumerNum(consumerNumber);
				consumerBillBean.setBillNum(resultSet.getLong("bill_num"));
				consumerBillBean.setBillMonth(resultSet.getString(2));
				consumerBillBean.setCurrentRead(resultSet.getFloat("cur_reading"));
				consumerBillBean.setUnitsConsumed(resultSet.getFloat("unitConsumed"));
				consumerBillBean.setNetAmount(resultSet.getFloat("netAmount"));
				
				consumerBillList.add(consumerBillBean);
			}
		}
		catch(SQLException e)
		{
			throw new ConsumerException(e.getMessage());
		}
		return consumerBillList;
	}
	
	@Override
	public long insertBillDetails(ConsumerBillBean consumerBillBean,ConsumerBean consumerBean) throws ConsumerException
	{
		long billNumber=0;
		int queryResult=0;
		
		try 
		{
			preparedStatement=connection.prepareStatement(IQueryMapper.INSERT_INSERTBILLDETAILS_QUERY);
			preparedStatement.setLong(1,consumerBillBean.getConsumerNum());
			preparedStatement.setFloat(2,consumerBillBean.getCurrentRead());
			preparedStatement.setFloat(3,consumerBillBean.getUnitsConsumed());
			preparedStatement.setFloat(4,consumerBillBean.getNetAmount());
			queryResult=preparedStatement.executeUpdate();
			
			if(queryResult>0)
			{
				preparedStatement1 = connection.prepareStatement(IQueryMapper.SELECT_SEQ_QUERY);
				
				resultSet=preparedStatement1.executeQuery();
	
				if(resultSet.next())
				{
					billNumber=resultSet.getInt(1);
					consumerBillBean.setBillNum(billNumber);
				}
			}
		
			preparedStatement=connection.prepareStatement(IQueryMapper.SELECT_NAME_QUERY);
			preparedStatement.setLong(1,consumerBillBean.getConsumerNum());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				String consumerName=resultSet.getString("consumer_name");
				consumerBean.setConsumerName(consumerName);
			}
		}
		catch(SQLException e) 
		{
			throw new ConsumerException("No data found for entered id");
		}
		return billNumber;
	}


}
