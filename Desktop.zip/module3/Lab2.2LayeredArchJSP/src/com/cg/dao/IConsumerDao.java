package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.ConsumerBean;
import com.cg.bean.ConsumerBillBean;
import com.cg.exception.ConsumerException;

public interface IConsumerDao 
{
	public ArrayList<ConsumerBean> showTable() throws ConsumerException;
	public ConsumerBean getConsumerDetails(long consumerNumber) throws ConsumerException;
	public ArrayList<ConsumerBillBean> getBillDetails(long consumerNumber) throws ConsumerException;
	public long insertBillDetails(ConsumerBillBean consumerBillBean,ConsumerBean consumerBean) throws ConsumerException;
}
