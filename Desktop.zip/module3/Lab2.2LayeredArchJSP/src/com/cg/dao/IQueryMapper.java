package com.cg.dao;

public interface IQueryMapper 
{
	public static final String SELECT_SHOWTABLE_QUERY="SELECT consumer_num,consumer_name,address FROM Consumers";
	public static final String SELECT_GETCONSUMERDETAILS_QUERY="SELECT consumer_num,consumer_name,address FROM Consumers WHERE consumer_num=?";
	public static final String SELECT_GETBILLDETAILS_QUERY="SELECT bill_num,TO_CHAR(bill_date,'MONTH'),cur_reading,unitConsumed,netAmount FROM BillDetails WHERE consumer_num=?";
	public static final String INSERT_INSERTBILLDETAILS_QUERY="INSERT INTO BillDetails VALUES(seq_bill_num.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String SELECT_SEQ_QUERY="SELECT seq_bill_num.CURRVAL FROM DUAL";
	public static final String SELECT_NAME_QUERY="SELECT consumer_name FROM Consumers WHERE consumer_num=?";
}
