package com.cg.bean;

public class ConsumerBean 
{
	private long consumerNum; 
	private String consumerName;
	private String consumerAddress;
	
	public long getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(long consumerNum) {
		this.consumerNum = consumerNum;
	}
	public String getConsumerName() {
		return consumerName;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}
	public String getConsumerAddress() {
		return consumerAddress;
	}
	public void setConsumerAddress(String consumerAddress) {
		this.consumerAddress = consumerAddress;
	}
}
