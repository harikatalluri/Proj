package com.cg.bean;

public class ConsumerBillBean 
{
	private long consumerNum;
	private long billNum;	
	private float lastRead;
	private float currentRead;
	private float unitsConsumed;
	private float netAmount;
	private String billMonth;
	
	public long getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(long consumerNum) {
		this.consumerNum = consumerNum;
	}
	public long getBillNum() {
		return billNum;
	}
	public void setBillNum(long billNum) {
		this.billNum = billNum;
	}
	public float getLastRead() {
		return lastRead;
	}
	public void setLastRead(float lastRead) {
		this.lastRead = lastRead;
	}
	public float getCurrentRead() {
		return currentRead;
	}
	public void setCurrentRead(float currentRead) {
		this.currentRead = currentRead;
	}
	public float getUnitsConsumed() {
		return unitsConsumed;
	}
	public void setUnitsConsumed(float unitsConsumed) {
		this.unitsConsumed = unitsConsumed;
	}
	public float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}
	public String getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}
}
