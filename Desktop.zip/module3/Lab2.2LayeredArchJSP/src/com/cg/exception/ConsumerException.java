package com.cg.exception;

public class ConsumerException extends Exception
{
	private static final long serialVersionUID = 1L;

	public ConsumerException(String message) 
	{
		super(message);
	}
}
