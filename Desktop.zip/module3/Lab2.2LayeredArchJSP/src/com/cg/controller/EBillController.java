package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.ConsumerBean;
import com.cg.bean.ConsumerBillBean;
import com.cg.exception.ConsumerException;
import com.cg.service.ConsumerServiceImpl;
import com.cg.service.IConsumerService;

@WebServlet("/EBillController")
public class EBillController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	float units=0;
	float netAmount=0;
	int fixedCharge=100;
	long billNumber=0;
	
	IConsumerService consumerService=new ConsumerServiceImpl();
	ConsumerBean consumerBean=new ConsumerBean();
	ConsumerBillBean consumerBillBean=new ConsumerBillBean(); 
	ArrayList<ConsumerBean> consumerList=null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		
		String option=request.getParameter("option");
		
		//To validate the login page
		if(option!= null && option.equals("submit"))
		{
			String userid=request.getParameter("uid");
			String pswd=request.getParameter("pwd");
			if(isValidCustomer(userid,pswd))
			{
				RequestDispatcher rd=request.getRequestDispatcher("/index.html");
				rd.forward(request,response);
			}
			else
			{
				response.sendRedirect("login.html");
			}
		}
		
		//To display list of consumers table
		else if(option!=null && option.equals("listConsumers"))
		{
			ArrayList<ConsumerBean> consumerList=null;
			try 
			{
				consumerList=consumerService.showTable();
				
				request.setAttribute("consList",consumerList);
				
				RequestDispatcher rd=request.getRequestDispatcher("/Show_ConsumerList.jsp");
				rd.forward(request,response);
			}
			catch (ConsumerException e) 
			{
				out.println(e.getMessage());
			}
		}
		
		//To search for a particular consumer and show consumer
		else if(option!=null && option.equals("Search"))
		{
			long consumerNumber=Long.parseLong(request.getParameter("consumerNumber"));
			try 
			{
				consumerBean=consumerService.getConsumerDetails(consumerNumber);
				
				if(consumerBean!=null)
				{
					request.setAttribute("consumerBean",consumerBean);
					request.setAttribute("consumerNumber",String.valueOf(consumerBean.getConsumerNum()));
					
					ServletContext context=getServletContext();
					RequestDispatcher rd=context.getRequestDispatcher("/Show_Consumer.jsp");
					rd.forward(request,response);
				}
				else
				{
					request.setAttribute("consumerNumber",consumerNumber);
					
					ServletContext context=getServletContext();
					RequestDispatcher rd=context.getRequestDispatcher("/Error.jsp");
					rd.forward(request,response);
				}
				
			} 
			catch (ConsumerException e) 
			{
				out.println(e.getMessage());
			}	
		}
		
		//to generate bill details
		else if(option!=null && option.equals("ShowBill"))
		{

			long consumerNumber=Long.parseLong((String)request.getParameter("consumerNumber"));
			
			ArrayList<ConsumerBillBean> consumerBillList=null;
			try 
			{
				consumerBillList=consumerService.getBillDetails(consumerNumber);
			
				request.setAttribute("consumerBillList",consumerBillList);
				request.setAttribute("consumerNumber",consumerNumber);
				
				ServletContext context=getServletContext();
				RequestDispatcher rd2=context.getRequestDispatcher("/Show_Bills.jsp");
				rd2.forward(request,response);
			}
			catch (ConsumerException e) 
			{
				out.println(e.getMessage());
			}
		}
		
		//to generate next bill and show bill details
		else if(option!= null && option.equals("Calculate Bill"))
		{
			long consumerNumber=Long.parseLong(request.getParameter("consumerNumber"));
			float lastMonthRead=Float.parseFloat(request.getParameter("lastRead"));
			float currentMonthRead=Float.parseFloat(request.getParameter("currentRead"));
			
			if(currentMonthRead>lastMonthRead)
			{	
				float netAmount=calculateNetAmount(currentMonthRead,lastMonthRead);
				
				consumerBillBean.setConsumerNum(consumerNumber);
				consumerBillBean.setLastRead(lastMonthRead);
				consumerBillBean.setCurrentRead(currentMonthRead);
				consumerBillBean.setUnitsConsumed(units);
				consumerBillBean.setNetAmount(netAmount);
				
				try 
				{
					billNumber=consumerService.insertBillDetails(consumerBillBean,consumerBean);
					
					request.setAttribute("consumerBillBean",consumerBillBean);
					request.setAttribute("consumerBean",consumerBean);
					
					ServletContext context=getServletContext();
					RequestDispatcher rd=context.getRequestDispatcher("/Bill_Info.jsp");
					rd.forward(request,response);
				}
				catch (ConsumerException e) 
				{
					out.println(e.getMessage());
				}
			}
			else
			{
				response.sendRedirect("User_Info.jsp");
			}
		}
	}
	
	public boolean isValidCustomer(String userid,String pswd)
	{
		if(userid.equals("harika") && pswd.equals("abc123"))
		{
			return true;
		} 
		else 
		{
			return false;	
		}
	}
	
	public float calculateNetAmount(float currentMonthRead,float lastMonthRead)
	{
		units=currentMonthRead-lastMonthRead;
		netAmount=(float) ((units*1.15)+fixedCharge);
		return netAmount;
	}

	

}
