package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.ConsumerBean;
import com.cg.bean.ConsumerBillBean;
import com.cg.dao.ConsumerDaoImpl;
import com.cg.dao.IConsumerDao;
import com.cg.exception.ConsumerException;

public class ConsumerServiceImpl implements IConsumerService
{
	IConsumerDao consumerDaoImpl=new ConsumerDaoImpl();
	
	@Override
	public ArrayList<ConsumerBean> showTable() throws ConsumerException
	{
		return  consumerDaoImpl.showTable();
	}
	
	@Override
	public ConsumerBean getConsumerDetails(long consumerNumber) throws ConsumerException
	{
		return consumerDaoImpl.getConsumerDetails(consumerNumber);
	}
	
	@Override
	public ArrayList<ConsumerBillBean> getBillDetails(long consumerNumber) throws ConsumerException
	{
		return consumerDaoImpl.getBillDetails(consumerNumber);
	}
	
	@Override
	public long insertBillDetails(ConsumerBillBean consumerBillBean,ConsumerBean consumerBean) throws ConsumerException
	{
		return consumerDaoImpl.insertBillDetails(consumerBillBean,consumerBean);
	}
}
