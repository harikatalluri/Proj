package com.capgemini.cab.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.cab.exception.CabBookingException;
import com.capgemini.cab.service.CabService;
import com.capgemini.cab.service.ICabService;
import com.capgemini.cabs.bean.CabRequest;

public class CabBookingTest 
{

		//Test request id 
		@Test
		public void rechargeCustomer() throws CabBookingException 
		{
			ICabService cabservice = new CabService();
			CabRequest cabrequest=new CabRequest();
			cabrequest.setCustomerName("John");
			cabrequest.setPhoneNumber("9768587350");;
			cabrequest.setAddressOfPickup("Capgemini Knowledge Park, IT 1 / IT 2, TTC Industrial Area,Thane-Belapur Road, Airoli< Navi Mumbai");
			cabrequest.setPincode("400708");
			int result = cabservice.addCabRequestDetails(cabrequest);
			assertEquals(1004, result);
		}
	}

