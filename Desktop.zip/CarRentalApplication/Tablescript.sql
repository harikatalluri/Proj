CREATE TABLE cab_request(
request_id NUMBER,
customer_name VARCHAR2(20),
phone_number VARCHAR2(10),
date_of_request DATE,
request_status VARCHAR2(12),
cab_number VARCHAR2(15),
address_of_pickup VARCHAR2(50),
pincode VARCHAR2(6));

CREATE SEQUENCE seq_request_id
START with 1001;