package com.capgemini.cabs.ui;

import java.util.Scanner;

import com.capgemini.cab.exception.CabBookingException;
import com.capgemini.cab.service.CabService;
import com.capgemini.cabs.bean.CabRequest;

public class Client 
{
	public static void main(String[] args) 
	{
		CabRequest cabRequest=new CabRequest();
		CabService cabService=new CabService();
		String name=null;
		String phnNumber=null;
		String pickUpAddress=null;
		String pincode=null;
		int choice=0;
		int requestId=0;
		Scanner sc=new Scanner(System.in);
		do{
			System.out.println("Select your choice \n1) Raise Cab Request \n2) View Cab Request Status \n3) Exit");
			choice=sc.nextInt();
			switch(choice)
			{
				case 1:
				{	
					do
					{
						System.out.println("Enter the name of the customer: ");
						name=sc.next();
					}while(cabService.isNameValid(name));
					cabRequest.setCustomerName(name);
				
					do
					{
						System.out.println("Enter customer phone number: ");
						phnNumber=sc.next();
					}while(cabService.isNumberValid(phnNumber));
					cabRequest.setPhoneNumber(phnNumber);
				
					System.out.println("Enter Pick up address: ");
					sc.nextLine();
					pickUpAddress=sc.nextLine();
					cabRequest.setAddressOfPickup(pickUpAddress);
					
					System.out.println("Enter Pin Code: ");
					pincode=sc.next();
					cabRequest.setPincode(pincode);
					cabService.isPincodeValid(pincode);
					
					try
					{
						if(pincode.equals("400096") || pincode.equals("411026") ||pincode.equals("411013") || pincode.equals("560066")||pincode.equals("382009") || pincode.equals("400708"))
						{
							requestId=cabService.addCabRequestDetails(cabRequest);
							if(requestId>0)
								System.out.println("Your Cab Request has been successfully registered, your request ID is : "+requestId);
						}
						else
						{
							System.out.println("invalid pincode");
						}
					}
					catch(CabBookingException e)
					{
						System.out.println(e.getMessage());
					}
					break;
				}
				case 2:
				{
					System.out.println("Enter your RequestId:");
					int reqId=sc.nextInt();
					try
					{
						cabRequest=cabService.getRequestDetails(reqId);
						System.out.println("Name of the Customer : "+cabRequest.getCustomerName());
						System.out.println("Request Status : "+cabRequest.getRequestStatus());
						System.out.println("Cab number : "+cabRequest.getCabNumber());
						System.out.println("Pickup Address : "+cabRequest.getAddressOfPickup());
					}
					catch(CabBookingException e)
					{
						System.out.println(e.getMessage());
					}
					break;
				}
				case 3:
					System.exit(0);
				default:
					System.out.println("Please select a valid option");
					break;
			}
			System.out.println("\n");
		}while(choice!=3);
		sc.close();
	}
}
