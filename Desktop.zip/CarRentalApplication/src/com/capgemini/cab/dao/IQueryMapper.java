package com.capgemini.cab.dao;

//SQL final queries
public interface IQueryMapper 
{
	public static final String INSERT_QUERY="INSERT INTO cab_request(request_id,customer_name,phone_number,date_of_request,request_status,cab_number,address_of_pickup,pincode) VALUES (seq_request_id.NEXTVAL,?,?,SYSDATE,?,?,?,?)";
	public static final String REQUESTID_QUERY_SEQUENCE="SELECT seq_request_id.CURRVAL from DUAL";
	public static final String VIEW_CAB_DETAILS_QUERY="SELECT customer_name,request_status,cab_number,address_of_pickup from cab_request WHERE request_id=?";
} 