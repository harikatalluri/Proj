package com.capgemini.cab.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.cab.exception.CabBookingException;
import com.capgemini.cab.util.ClientDBConnection;
import com.capgemini.cabs.bean.CabRequest;

public class CabRequestDAO implements ICabRequestDAO
{
	Logger logger=Logger.getRootLogger();
	public CabRequestDAO()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	int reqId;

	
	//------------------------ 1. Cab booking --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addCabRequestDetails(CabRequest cabRequest)
	 - Input Parameters	:	CabRequest cabRequest
	 - Return Type		:	int
	 - Throws			:  	CabBookingException
	 - Author			:	Harika
	 - Creation Date	:	20/06/2018
	 - Description		:	adding cab booking details
	 ********************************************************************************************************/
	@Override
	public int addCabRequestDetails(CabRequest cabRequest) throws CabBookingException
	{
		Connection connection = ClientDBConnection.getConnection();	
		
		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet = null;
		
		int requestId=0;
		int queryResult=0;
		
		try
		{		
			logger.info("Connection established");
			preparedStatement=connection.prepareStatement(IQueryMapper.INSERT_QUERY);
			preparedStatement.setString(1,cabRequest.getCustomerName());			
			preparedStatement.setString(2,cabRequest.getPhoneNumber());
			preparedStatement.setString(3,cabRequest.getRequestStatus());
			preparedStatement.setString(4,cabRequest.getCabNumber());	
			preparedStatement.setString(5,cabRequest.getAddressOfPickup());
			preparedStatement.setString(6,cabRequest.getPincode());
			
			queryResult=preparedStatement.executeUpdate();
			
			preparedStatement1 = connection.prepareStatement(IQueryMapper.REQUESTID_QUERY_SEQUENCE);
			resultSet=preparedStatement1.executeQuery();

			if(resultSet.next())
			{
				requestId=resultSet.getInt(1);
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed");
				reqId=0;
				throw new CabBookingException("Inserting recharge details failed ");
			}
			else
			{	
				connection.commit();
				reqId=requestId;
				logger.info("Request details added successfully");
			}
		}
		catch(SQLException sqlException)
		{
			throw new CabBookingException("Caught "+sqlException.getMessage());
		}
		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new CabBookingException("Error in closing db connection");
			}
		}
		return reqId;
	}

	//------------------------ 1. Cab booking --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getRequestDetails(int requestId)
			 - Input Parameters	:	int requestId
			 - Return Type		:	CabRequest
			 - Throws			:  	CabBookingException
			 - Author			:	Harika
			 - Creation Date	:	20/06/2018
			 - Description		:	returning cab booking details
			 ********************************************************************************************************/
	public CabRequest getRequestDetails(int requestId) throws CabBookingException
	{
		logger.info("Connection established");
		CabRequest cabRequest1=new CabRequest();
		Connection connection = ClientDBConnection.getConnection();	
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_CAB_DETAILS_QUERY);
			preparedStatement.setInt(1,requestId);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
					cabRequest1.setCustomerName(resultSet.getString("customer_name"));
					cabRequest1.setRequestStatus(resultSet.getString("request_status"));
					cabRequest1.setCabNumber(resultSet.getString("cab_number"));
					cabRequest1.setAddressOfPickup(resultSet.getString("address_of_pickup"));
			}
			else
				throw new CabBookingException("No data found for entered ID");
		}
		catch(SQLException sqlException)
		{
			throw new CabBookingException("Caught "+sqlException.getMessage());
		}
		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new CabBookingException("Error in closing db connection");
			}
		}
		return cabRequest1;
		
	}
}
