package com.capgemini.cab.dao;

import com.capgemini.cab.exception.CabBookingException;
import com.capgemini.cabs.bean.CabRequest;

public interface ICabRequestDAO 
{
	int addCabRequestDetails(CabRequest cabRequest) throws CabBookingException;
	CabRequest getRequestDetails(int requestId) throws CabBookingException;
}
