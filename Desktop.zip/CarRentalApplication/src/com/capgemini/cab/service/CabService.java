package com.capgemini.cab.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.cab.dao.CabRequestDAO;
import com.capgemini.cab.dao.ICabRequestDAO;
import com.capgemini.cab.exception.CabBookingException;
import com.capgemini.cabs.bean.CabRequest;

public class CabService implements ICabService 
{
	CabRequest cabRequest=new CabRequest();
	ICabRequestDAO cabRequestDAO=new CabRequestDAO();
	int requestId=0;
	public boolean isNameValid(String name)
	{
		Pattern pattern=Pattern.compile("[A-Z][a-zA-Z]{2,19}");
		Matcher matcher=pattern.matcher(name);
		if(!matcher.find())
		{
			System.out.println("Enter a valid name that starts with capital letter and minimum length should be 3 letters");
			return true;
		}
		else
			return false;
	}
	
	public boolean isNumberValid(String number)
	{
		Pattern pattern=Pattern.compile("[0-9]{10}");
		Matcher matcher=pattern.matcher(number);
		if(!matcher.find()) 
		{
			System.out.println("Enter a valid number with 10 digits");
			return true;
		}
		else
			return false;
	}
	
	public void isPincodeValid(String pincode)
	{
		if(pincode.equals("400096"))
		{
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH VS 2345");
		}
		else if(pincode.equals("411026"))
		{
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH VH 34567");
		}
		else if(pincode.equals("411013"))
		{
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH AN 97886");
		}
		else if(pincode.equals("560066"))
		{
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH AS 875");
		}
		else if(pincode.equals("400096"))
		{
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH KN 9856");
		}
		else if(pincode.equals("400096"))
		{
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH TF 8956");
		}
		else
		{
			cabRequest.setRequestStatus("Not Accepted");
			cabRequest.setCabNumber(null);
		}
	}
	
	@Override
	public int addCabRequestDetails(CabRequest cabRequest) throws CabBookingException
	{
		requestId=cabRequestDAO.addCabRequestDetails(cabRequest);
		return requestId;
	}
	
	@Override
	public CabRequest getRequestDetails(int requestId) throws CabBookingException
	{
		cabRequest=cabRequestDAO.getRequestDetails(requestId);
		return cabRequest;
	}
}
