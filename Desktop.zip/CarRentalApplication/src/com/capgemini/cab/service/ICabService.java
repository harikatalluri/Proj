package com.capgemini.cab.service;

import com.capgemini.cab.exception.CabBookingException;
import com.capgemini.cabs.bean.CabRequest;

public interface ICabService 
{
	int addCabRequestDetails(CabRequest cabRequest) throws CabBookingException;
	CabRequest getRequestDetails(int requestId) throws CabBookingException;
}
