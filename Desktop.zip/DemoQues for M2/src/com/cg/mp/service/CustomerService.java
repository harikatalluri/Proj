package com.cg.mp.service;

import java.util.regex.*;
import com.cg.mp.bean.*;
import com.cg.mp.exception.Mobileplanexception;
import com.cg.mp.dao.*;

public class CustomerService implements ICustomer 
{
	Customerbean cb=new Customerbean();
	ICustomerdao cd=new CustomerDao();
	int val;
	
	@Override
	public boolean isNameValid(String name)
	{
		Pattern pattern=Pattern.compile("[A-Z][a-zA-Z]{5,19}");
		Matcher matcher=pattern.matcher(name);
		if(!matcher.find())
		{
			System.out.println("Enter a valid name that starts with capital letter and minimum length should be 6 letters");
			return true;
		}
		else
			return false;
	}
	
	@Override
	public boolean isNumberValid(String number)
	{
		Pattern pattern=Pattern.compile("[0-9]{10}");
		Matcher matcher=pattern.matcher(number);
		if(!matcher.find()) 
		{
			System.out.println("Enter a valid number with 10 digits");
			return true;
		}
		else
			return false;
	}
	
	@Override
	public boolean isEmailValid(String email)
	{
		Pattern pattern=Pattern.compile("^[A-Za-z0-9]{1,20}[@]{1}[A-Za-z0-9.]{1,20}");
		Matcher matcher=pattern.matcher(email);
		if(!matcher.find())
		{
			System.out.println("Enter a valid email id. Email id should have @ character");
			return true;
		}
		else
			return false;
	}
	
	@Override
	public boolean isPlanNameValid(String plan)
	{
		if(plan.equals("Rc99") || plan.equals("Rc150") || plan.equals("Rc299") ||plan.equals("Rc500"))
			return false;
		else
		{
			System.out.println("Enter a valid plan name");
			return true;
		}
	}
	
	@Override
	public int calculateAmount(String plan)
	{
		if(plan.equals("Rc99"))
			val=99;
		if(plan.equals("Rc150"))
			val=150;
		if(plan.equals("Rc299"))
			val=299;
		if(plan.equals("Rc500"))
			val=500;
		return val;
	}
	
	@Override
	public int addRechargeInfo(Customerbean cb) throws Mobileplanexception
	{
		int rechId=cd.addRechargeInfo(cb);
		return rechId;
	}
	@Override
	public void getInfoById(int rechnum) throws Mobileplanexception
	{
		cd.getInfoById(rechnum);
	}
}