package com.cg.mp.exception;

public class Mobileplanexception extends Exception 
{
	private static final long serialVersionUID = 1L;

	public Mobileplanexception(String message) 
	{
		super(message);
	}
}
