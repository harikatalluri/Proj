package com.cg.mp.bean;

public class Customerbean 
{
	private String name;
	private String phnnum;
	private String emailid;
	private String planname;
	private int amount;
	
	
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhnnum() {
		return phnnum;
	}
	public void setPhnnum(String phnnum) {
		this.phnnum = phnnum;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getPlanname() {
		return planname;
	}
	public void setPlanname(String planname) {
		this.planname = planname;
	}
	
	/*public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Printing Donor Details \n");
		sb.append("Name: " +name +"\n");
		sb.append("Mobile number: "+ phnnum +"\n");
		sb.append("EmailId: "+ emailid +"\n");
		sb.append("Plan name: "+ planname );
		return sb.toString();
	}*/
	
}
