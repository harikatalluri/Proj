package com.cg.mp.service;

import com.cg.mp.bean.Customerbean;
import com.cg.mp.exception.Mobileplanexception;

public interface ICustomer 
{
	public abstract boolean isNameValid(String name);
	public abstract boolean isNumberValid(String number);
	public abstract boolean isEmailValid(String email); 
	public abstract boolean isPlanNameValid(String plan);
	public abstract int calculateAmount(String plan);
	public abstract int addRechargeInfo(Customerbean cb) throws Mobileplanexception;
	public abstract void getInfoById(int rechnum) throws Mobileplanexception;
}