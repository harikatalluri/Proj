package com.cg.mp.pi;

import java.util.Scanner;

import com.cg.mp.exception.*;
import com.cg.mp.service.*;
import com.cg.mp.bean.*;

public class Customermain 
{
	public static void main(String args[]) 
	{
		Customerbean cb=new Customerbean();
		CustomerService cs=new CustomerService();
		String name=null;
		String number=null;
		String email=null;
		String plan=null;
		int choice=0;
		Scanner sc=new Scanner(System.in);
		do{
			System.out.println("Enter your option \n1.Recharge \n2.Display details of recharge \n3.Exit");
			choice=sc.nextInt();
			switch(choice)
			{
				case 1:
				{	
					do
					{
						System.out.println("Enter name: ");
						name=sc.next();
					}while(cs.isNameValid(name));
					cb.setName(name);
				
					do
					{
						System.out.println("Enter mobile number: ");
						number=sc.next();
					}while(cs.isNumberValid(number));
					cb.setPhnnum(number);
				
					do
					{
						System.out.println("Enter email id: ");
						email=sc.next();
					}while(cs.isEmailValid(email));
					cb.setEmailid(email);
				
					System.out.println("--------------------------");
					System.out.println("|  Plan name  |  amount  |");
					System.out.println("--------------------------");
					System.out.println("|    Rc99     |    99    |");
					System.out.println("|    Rc150    |    150   |");
					System.out.println("|    Rc299    |    299   |");
					System.out.println("|    Rc500    |    500   |");
					System.out.println("--------------------------");
				
					do
					{
						System.out.println("Enter a plan name: ");
						plan=sc.next();
					}while(cs.isPlanNameValid(plan));
					cb.setPlanname(plan);
					
					int amt=cs.calculateAmount(plan);
					cb.setAmount(amt);
					
					try
					{
						int rechId=cs.addRechargeInfo(cb);
						if(rechId>0)
							System.out.println("Your mobile has been recharged. RechargeId is: "+rechId);
					}
					catch(Mobileplanexception e)
					{
						System.out.println(e.getMessage());
					}
					break;
				}
				case 2:
				{
					System.out.println("Enter your recharge id:");
					int rechnum=sc.nextInt();
					try
					{
						cs.getInfoById(rechnum);
					}
					catch(Mobileplanexception e)
					{
						System.out.println(e.getMessage());
					}
					break;
				}
				case 3:
					System.exit(0);
					break;
				default:
					System.out.println("Please select a valid option");
					break;
			}
		}while(choice!=3);
	sc.close();
	}
}