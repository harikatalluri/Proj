package com.cg.mp.dao;

import com.cg.mp.exception.Mobileplanexception;
import com.cg.mp.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.DriverManager;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mp.bean.*;

public class CustomerDao implements ICustomerdao
{
	Logger logger=Logger.getRootLogger();
	public CustomerDao()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	int i; 
	
	
	//------------------------ 1. Mobile Recharge --------------------------
		/*******************************************************************************************************
		 - Function Name	:	addRechargeInfo(Customerbean cb)
		 - Input Parameters	:	Customerbean cb
		 - Return Type		:	Integer
		 - Throws			:  	Mobileplanexception
		 - Author			:	Harika
		 - Creation Date	:	18/06/2018
		 - Description		:	adding recharge information
		 ********************************************************************************************************/
	@Override
	public int addRechargeInfo(Customerbean cb) throws Mobileplanexception 
	{
		Connection connection = CustomerDBConnection.getConnection();	
		
		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet = null;
		
		int rechId=0;
		
		int queryResult=0;
		
		try
		{		
			preparedStatement=connection.prepareStatement(IQueryMapper.INSERT_QUERY);
			preparedStatement.setString(1,cb.getName());			
			preparedStatement.setString(2,cb.getPhnnum());
			preparedStatement.setString(3,"Success");
			preparedStatement.setString(4,cb.getPlanname());	
			preparedStatement.setInt(5,cb.getAmount());
			
			queryResult=preparedStatement.executeUpdate();
			
			preparedStatement1 = connection.prepareStatement(IQueryMapper.RECHARGEID_QUERY_SEQUENCE);
			resultSet=preparedStatement1.executeQuery();
			connection.commit();

			if(resultSet.next())
			{
				rechId=resultSet.getInt(1);
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed");
				i=0;
				throw new Mobileplanexception("Inserting recharge details failed ");
			}
			else
			{	connection.commit();
				logger.info("Plan details added successfully");
				i=rechId;
			}

		}
		catch(SQLException sqlException)
		{
			throw new Mobileplanexception("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				preparedStatement1.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new Mobileplanexception("Error in closing db connection");
			}
		}
		return i;
	} 

	
	//------------------------ 1. Mobile Recharge --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getInfoById(int rechid)
			 - Input Parameters	:	int rechid
			 - Return Type		:	void
			 - Throws			:  	Mobileplanexception
			 - Author			:	Harika
			 - Creation Date	:	18/06/2018
			 - Description		:	getting information of user
			 ********************************************************************************************************/
	@Override
	public void getInfoById(int rechid) throws Mobileplanexception
	{
		Connection connection = CustomerDBConnection.getConnection();	
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_RECHARGE_DETAILS_QUERY);
			preparedStatement.setInt(1,rechid);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
					String rname=resultSet.getString("name");
					String rmobile=resultSet.getString("mobile");
					String rplanname=resultSet.getString("planname");
					String ramount=resultSet.getString("amount");
					System.out.println("-----Details------");
					System.out.println("Name: "+rname);
					System.out.println("Mobile number: "+rmobile);
					System.out.println("Plan name: "+rplanname);
					System.out.println("Recharged with: "+ramount);
			}
			else
				throw new Mobileplanexception("No data found for entered ID");
		}
		catch(SQLException sqlException)
		{
			throw new Mobileplanexception("Caught "+sqlException.getMessage());
		}
		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new Mobileplanexception("Error in closing db connection");
			}
		}
		
	}

}
