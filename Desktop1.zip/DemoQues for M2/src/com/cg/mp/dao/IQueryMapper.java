package com.cg.mp.dao;

//SQL final queries
public interface IQueryMapper 
{
	public static final String INSERT_QUERY="INSERT INTO custtable(rechid,name,mobile,status,planname,amount) VALUES (cust_seq.NEXTVAL,?,?,?,?,?)";
	public static final String RECHARGEID_QUERY_SEQUENCE="SELECT cust_seq.CURRVAL from DUAL";
	public static final String VIEW_RECHARGE_DETAILS_QUERY="SELECT name,mobile,planname,amount from custtable WHERE rechid=?";
} 