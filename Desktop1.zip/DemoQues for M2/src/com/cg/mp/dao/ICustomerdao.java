package com.cg.mp.dao;

import com.cg.mp.exception.Mobileplanexception;
import com.cg.mp.bean.*;

public interface ICustomerdao 
{
	public abstract int addRechargeInfo(Customerbean cb) throws Mobileplanexception;
	public abstract void getInfoById(int rechnum) throws Mobileplanexception;
}
