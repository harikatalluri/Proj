CREATE SEQUENCE cust_seq 
INCREMENT BY 1 
START WITH 1001 
MAXVALUE 10000 
NOCYCLE;

CREATE TABLE custtable(
rechid NUMBER,
name VARCHAR2(20),
mobile VARCHAR2(10),
status varchar2(10),
planname VARCHAR2(10),
amount NUMBER);
