package com.cg.mp.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.mp.bean.Customerbean;
import com.cg.mp.exception.Mobileplanexception;
import com.cg.mp.service.*;

public class MobileRechargeTest 
{
	//Test recharge plan
	@Test
	public void rechargeCustomer() throws Mobileplanexception {
		ICustomer cs = new CustomerService();
		Customerbean cb = new Customerbean();
		cb.setName("Harika");
		cb.setPhnnum("9492150082");
		cb.setPlanname("Rc500");
		cb.setEmailid("harika@cg.com");
		int result = cs.addRechargeInfo(cb);
		assertEquals(1004, result);
	}
	
	/*@Test
	public void getCustomerDetails() throws Mobileplanexception{
		ICustomer cs = new CustomerService();
		Customerbean cb = new Customerbean();
		cs.getInfoById(1001);
		assertEquals("", cs.getInfoById(1001));
	}*/

}

