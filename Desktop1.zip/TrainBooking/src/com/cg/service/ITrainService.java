package com.cg.service;

import java.util.*;
import com.cg.Exception.BookingException;
import com.cg.bean.*;

public interface ITrainService 
{
	ArrayList<TrainBean> retrieveTrainDetails();
	int bookTicket(BookingBean bookingbean) throws BookingException;
}
