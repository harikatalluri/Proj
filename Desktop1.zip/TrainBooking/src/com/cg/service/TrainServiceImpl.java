package com.cg.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

import com.cg.bean.BookingBean;
import com.cg.bean.TrainBean;
import com.cg.dao.ITrainDao;
import com.cg.dao.TrainDaoImpl;
import com.cg.Exception.BookingException;

public class TrainServiceImpl implements ITrainService
{
	String cid;
	BookingBean b=new BookingBean();
	ITrainDao d=new TrainDaoImpl()
	/*{
	@Override
	public ArrayList<TrainBean> retrieveTrainDetails()
	{
		d.retrieveTrainDetails();
		return null;
	}
	
	@Override
	public int bookTicket(BookingBean bookingbean) throws BookingException
	{
		return 0;
	}
	}*/;
	
	@Override
	public ArrayList<TrainBean> retrieveTrainDetails()
	{
		d.retrieveTrainDetails();
		return null;
	}
	
	@Override
	public int bookTicket(BookingBean bookingbean) throws BookingException
	{
		d.bookTicket(bookingbean);
		while(true)
		{
			System.out.println("Enter the id of the customer");
			Scanner scan=new Scanner(System.in);
			cid=scan.nextLine();
			scan.close();
			Pattern unp=Pattern.compile("^[0-9]{6}");
			Matcher mtcnn=unp.matcher(cid);
			if(!mtcnn.find())
				System.out.println("First character should be capital and then followed by 6 difits");
			else
			{
				b.setCustid(cid);
				break;
			}
		}
		int customerId=Integer.parseInt(cid);
		return customerId;
	}
}