package com.cg.dao;

import java.util.ArrayList;
import com.cg.Exception.BookingException;
import com.cg.bean.*;

public interface ITrainDao 
{
	ArrayList<TrainBean> retrieveTrainDetails();
	int bookTicket(BookingBean bookingbean) throws BookingException;
}
