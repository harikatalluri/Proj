package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

//import org.apache.log4j.Logger;
//import org.apache.log4j.PropertyConfigurator;

import com.cg.Exception.BookingException;
import com.cg.bean.BookingBean;
import com.cg.bean.TrainBean;

public class TrainDaoImpl implements ITrainDao
{
	java.util.logging.Logger logger=java.util.logging.Logger.getAnonymousLogger();
	public TrainDaoImpl()
	{
	}
	int count=0;
	String cid;
	int trid;
	int seat;
	int bookingid;
	String trainId;
	Statement st;
	ResultSet rs1;
	ResultSet rs2;
	ResultSet rs3;
	Connection con;
	PreparedStatement pst=null;
	PreparedStatement pst1=null;
	PreparedStatement pst2=null;
	
	@Override
	public ArrayList<TrainBean> retrieveTrainDetails()
	{
		int trainCount=0;
		PreparedStatement ps=null;
		ResultSet resultset=null;
		
		ArrayList<TrainBean> trainList=new ArrayList<TrainBean>();
		try
		{
			ps=con.prepareStatement("SELECT * FROM TrainDetails");
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{
				TrainBean bean=new TrainBean();
				bean.setTrainid(resultset.getInt(1));
				bean.setTrainType(resultset.getString(2));
				bean.setFromStop(resultset.getString(3));
				bean.setToStop(resultset.getString(4));
				bean.setAvailableSeats(resultset.getInt(5));
				//bean.setDateOfJourney(resultset.getDate(6));
				trainList.add(bean);
				trainCount++;
			}
		}
		catch(SQLException sqlException)
		{
			//logger.error(sqlException.getMessage());
			System.out.println("caught "+sqlException);
		}
		if(trainCount==0)
			return null;
		else
			return trainList;
	}
	
	@Override
	public int bookTicket(BookingBean bookingbean) throws BookingException
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg747","training747");
			Statement stmt=con.createStatement();
			
			while(true)
			{
				System.out.println("Enter the train id: ");
				Scanner sc=new Scanner(System.in);
				String trainId=sc.nextLine();
				Pattern pat=Pattern.compile("[0-9]{1,8}");
				Matcher match=pat.matcher(trainId);
				if(!match.find())
					System.out.println("Please enter a valid train number");
				else
				{
					trid=Integer.parseInt(trainId);
					rs1=st.executeQuery("SELECT * FROM TrainDetails");
					while(rs1.next());	//Mandatory to call this method next
					{
						if(trid==rs1.getInt("trainid"))		//this checks given train id with existing train id
						{
							count++;
							break;
						}
					}
					if(count==0)
					{
						System.err.println("Train ID should be existing train id");
					}
					else
					{
						break;
					}
				}
			}
			while(true)
			{
				int cnt=0;
				System.out.println("How many seats you want to book?");
				Scanner scan=new Scanner(System.in);
				seat=scan.nextInt();
				pst1=con.prepareStatement("SELECT availableSeats FROM TrainDetails where trainid=?");
				pst1.setInt(1,trid);
				rs2=pst1.executeQuery();	//This stores the number of seats customer wants to book
				while(rs2.next())
				{
					//System.out.println(rs2.getInt(1));	//Displays quantity based on mobile id selected by the user
					if(seat>Integer.parseInt(rs2.getString("availableseats")))
					{
						System.err.println("Sorry no seats available");
						cnt++;
					}
				}
				if(count>0)
				{
					rs3=st.executeQuery("CREATE TABLE BookingDetails(bookingid NUMBER,custid VARCHAR2(10), "
							+ "trainid REFERENCES TrainDetails(trainid), noOfSeats NUMBER");
					st.execute("CREATE SEQUENCE bookingid INCREMENT BY 1 START WITH 1000 MAXVALUE 10000 NOCYCLE");
					pst=con.prepareStatement("INSERT INTO BookingDetails VALUES(?,?,?,?)");
					pst.setInt(1,1000);
					pst.setString(2,cid);
					pst.setInt(3,trid);
					pst.setInt(4,seat);
					pst.executeUpdate();
					if(rs3.next())
					{
						bookingid=rs3.getInt(1);
					}
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return bookingid;
	}
}