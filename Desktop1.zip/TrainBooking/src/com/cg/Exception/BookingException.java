package com.cg.Exception;

public class BookingException extends Exception
{
	private static final long serialVersionUID = 1L;
	public BookingException()
	{
		System.out.println("There is a booking exception");
	}
}
