package com.cg.client;

import java.util.Scanner;
import com.cg.Exception.BookingException;
import com.cg.bean.BookingBean;
import com.cg.service.ITrainService;
import com.cg.service.TrainServiceImpl;

public class MainClient 
{
	public static void main(String args[])
	{
		ITrainService serv=new TrainServiceImpl();
		BookingBean bookingbean=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("WELCOME TO TRAIN TICKET BOOKING ONLINE");
		System.out.println("1.Booking Ticket \n 2.Exit \n");
		System.out.println("Enter your choice");
		int option=sc.nextInt();
		sc.close();
		switch(option)
		{
			case 1:
				System.out.println("You have selected for booking a ticket");
				try
				{
					serv.bookTicket(bookingbean);
				}
				catch(BookingException e)
				{
					e.printStackTrace();
				}
				break;
			case 2:
				System.out.println("You have selected exit option");
				System.exit(0);
		}	
	}
}
