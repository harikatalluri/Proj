package com.cg.test;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.Exception.BookingException;
import com.cg.bean.BookingBean;
import com.cg.dao.TrainDaoImpl;

public class BookTicketTest 
{
	@BeforeClass
	public static void main setUpBeforeClass() throws Exception
	{
		System.out.println("In before class");
	}
	@AfterClass
	public static void main tearDownAfterClass() throws Exception
	{
		
	}
	@Test
	public void testBookTicket() throws BookingException
	{
		TrainDaoImpl dao=new TrainDaoImpl();
		BookingBean bookingbean=null;
		assertNotNull(dao.bookTicket(bookingbean));
	}
}
