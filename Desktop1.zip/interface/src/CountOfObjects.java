public class CountOfObjects 
{
	public static void main(String[] args) 
	{
		//Employee2 e=new Employee2();
		Admin2 a =new Admin2();
		Manager2 m=new Manager2();
		Admin2 a1 =new Admin2();
		Manager2 m1=new Manager2();
		//e.work();
		//a.work();
		a.manage();
		m.plan();
		m.work();
		System.out.println("Number of employees are: "+Employee2.count);
	}
}

class Employee2
{
	public static int count=0;
	Employee2()
	{
		count++;
	}
	public void work()
	{
		System.out.println("Every employee should work");
	}
}

class Admin2 extends Employee2
{
	Admin2()
	{
		super();
	}
	public void manage()
	{
		//super.work();
		System.out.println("An admin manages the activities");
	}
	public void supervise()
	{
		System.out.println("An admin supervisess the activities");
	}
}

class  Manager2 extends Employee2
{
	Manager2()
	{
		super();
	}
	public void plan()
	{
		System.out.println("A manager plans the activities");
	}
	public void direct()
	{
		System.out.println("A manager directs the activities");
	}
}