public class Company 
{
	public static void main(String[] args) 
	{
		IContract ic=null;
		ic=new TrainingInstitution();
		ic.trainingJava();
		ic.trainingJsp();
	}
}
