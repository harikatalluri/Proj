public interface IContract
{
	public static final int DAYS=30;
	public static final String TOC=null;
	public abstract void trainingJava();
	public abstract void trainingJsp();
}
