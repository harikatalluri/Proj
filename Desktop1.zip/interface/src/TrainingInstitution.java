class TrainingInstitution implements IContract
{
	int balance=IContract.DAYS;
	public void trainingJava()
	{
		System.out.println("Training is being given on java");
		balance=balance-15;
		System.out.println("Remainig days after java: "+balance);
	}
	public void trainingJsp()
	{
		System.out.println("Training is being given on jsp");
		balance=balance-15;
		System.out.println("Remainig days after jsp: "+balance);
	}
}
