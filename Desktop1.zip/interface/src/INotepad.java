public interface INotepad 
{
	public static final int OPERATIONS=20;
	public abstract void newFile();
	public abstract void editFile();
	public abstract void saveFile();
	public abstract void closeFile();
}
