class OperatingSystem implements INotepad
{
	int num=OPERATIONS;
	public void newFile()
	{
		System.out.println("A new file has been created");
	}
	public void editFile()
	{
		System.out.println("The file has been changed");
		System.out.println("Number of operations can be done are: "+(num-3));
	}
	public void saveFile()
	{
		System.out.println("The file has been saved");
	}
	public void closeFile()
	{
		System.out.println("The file has been closed");
	}

}
