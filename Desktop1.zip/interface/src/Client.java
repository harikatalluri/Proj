public class Client 
{
	public static void main(String[] args) 
	{
		INotepad inp=null;
		inp=new OperatingSystem();
		inp.newFile();
		inp.editFile();
		inp.saveFile();
		inp.closeFile();
	}
}
