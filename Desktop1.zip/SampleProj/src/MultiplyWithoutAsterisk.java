import java.util.Scanner;
public class MultiplyWithoutAsterisk 
{
	public int multiply(int num1,int num2)
	{
		int prod=0;
		if(num1==0 || num2==0)
			return 0;
		else 
		{
			for(int i=0;i<num2;i++)
				prod=prod+num1;
			return prod;
		}
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number1: ");
		int num1=sc.nextInt();
		System.out.println("Enter number2: ");
		int num2=sc.nextInt();
		MultiplyWithoutAsterisk m=new MultiplyWithoutAsterisk();
		int product=m.multiply(num1,num2);
		System.out.println("The product of "+num1+" and "+num2+" is : "+product);
	}

}