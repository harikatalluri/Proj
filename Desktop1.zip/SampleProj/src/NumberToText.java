import java.util.Scanner;

public class NumberToText 
{
	public static void main(String[] args) 
	{
		int digit[] = new int[20];
		String units[]={"Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten",
						"Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"};
		String tens[] = {"","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"};

		int index=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num=sc.nextInt();
		sc.close();
		int num1=num;
		while(num!=0)
		{
			digit[index]=num%10;
			num=num/10;
			index++;
		}
		if(index==1)
			System.out.println(units[num1]);
		else if(index==2)
		{
			if(digit[0]<10 && digit[1]<=1)
				System.out.println(units[num1]);
			else if(digit[0]==0)
				System.out.println(tens[digit[1]]);
			else
				System.out.println(tens[digit[1]]+" "+units[digit[0]]);
		}
		else if(index==3)
		{
			if(num1%100==0)
				System.out.print(units[digit[2]]+" hundred");
			else if(digit[1]<=1)
			{
				System.out.print(units[digit[2]]+" hundred and ");
				int newnum=digit[1]*10+digit[0];
				System.out.println(units[newnum]);
			}
			else {
			System.out.print(units[digit[2]]+" hundred and ");
			if(digit[0]<10 && digit[1]<=1)
				System.out.println(units[num1]);
			else if(digit[0]==0)
				System.out.println(tens[digit[1]]);
			else
				System.out.println(tens[digit[1]]+" "+units[digit[0]]);	}
		}
		else
			System.out.println("Enter a number between 1 and 999");
	}
}
