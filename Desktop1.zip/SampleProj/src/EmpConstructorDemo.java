public class EmpConstructorDemo 
{
	public static void main(String[] args) 
	{
		Admin1 ad=new Admin1(1,"Harika","Admin");
		Manager1 mgr=new Manager1(2,"Deepika","Manager");
		Employee1 emp1=new Employee1(3,"abc");
		ad.AdminDisplay();
		mgr.ManagerDisplay();
		emp1.EmpDisplay();
	}
}

class Employee1
{
	int eId;
	String eName;
	Employee1(int eId,String eName)
	{
		this.eId=eId;
		this.eName=eName;
	}
	public void EmpDisplay()
	{
		System.out.println("Employee id: "+eId);
		System.out.println("Employee name: "+eName);
	}
}

class Admin1 extends Employee1
{
	String adrole;
	Admin1(int eId,String eName,String adrole)
	{
		super(eId,eName);
		this.adrole=adrole;
	}
	public void AdminDisplay()
	{
		System.out.println("Admin id: "+eId);
		System.out.println("Admin name: "+eName);
		System.out.println("Admin role: "+adrole);
	}
}

class Manager1 extends Employee1
{
	String mgrole;
	Manager1(int eId,String eName,String mgrole)
	{
		super(eId,eName);
		this.mgrole=mgrole;
	}
	public void ManagerDisplay()
	{
		System.out.println("Manager id: "+eId);
		System.out.println("Manager name: "+eName);
		System.out.println("Manager role: "+mgrole);
	}
}