public class EmployeeInheritence 
{
	public static void main(String[] args) 
	{
		Employee emp=new Employee();
		Adminn adm=new Adminn();
		SrAdmin sra=new SrAdmin();
		JrAdmin jra=new JrAdmin();
		Manager mgr=new Manager();
		SrManager srm=new SrManager();
		JrManager jrm=new JrManager();
		
		sra.ManagingInfo();
		jra.work();
		srm.work();
		jrm.work();
		jrm.superviseTeam();
	}
}

class Employee
{
	public void work()
	{
		System.out.println("Works");
	}
}

class Adminn extends Employee
{
	public void ManagingInfo()
	{
		System.out.println("Managing information");
	}
	public void DistributingInfo()
	{
		System.out.println("Distributing information");
	}
}

class SrAdmin extends Adminn
{
	public void ManagingPhnsEmails()
	{
		System.out.println("Managing phones and emails");
	}
	public void ScheduleAppointments()
	{
		System.out.println("Scheduling appointments");
	}
	public void PlanMeetings()
	{
		System.out.println("Planning meetings");
	}
}

class JrAdmin extends Adminn
{
	public void doClericalDuties()
	{
		System.out.println("Does clerical duties");
	}
}

class Manager extends Employee
{
	public void motivate()
	{
		System.out.println("Motivates");
	}
	public void communicate()
	{
		System.out.println("Communicates");
	}
}

class SrManager extends Manager
{
	public void planning()
	{
		System.out.println("Plans");
	}
	public void directing()
	{
		System.out.println("Directs");
	}
	public void monitor()
	{
		System.out.println("Monitors");
	}
}

class JrManager extends Manager
{
	public void superviseTeam()
	{
		System.out.println("Supervise the team");
	}
	public void handleEmpComplaints()
	{
		System.out.println("Handles Employee Complaints");
	}
}