import java.util.Scanner;
import java.io.Console;
import java.io.*;
public class AdminValidation 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		Console cons=System.console();
		boolean checkval;
		do
		{
			System.out.println("Enter User id: ");
			String name=sc.next().toLowerCase();
			System.out.println("Enter the password: ");
	        char[] ch=cons.readPassword();
	        String password = String.valueOf(ch);
			if(name.equals("admin") && password.equals("password"))
			{
				System.out.println("Valid user");
				checkval=true;
			}
			else
			{
				System.out.println("Invalid user");
				checkval=false;
			}
				
		}while(checkval==false);
	}

}
