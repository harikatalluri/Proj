public class VarArgsExp 
{
	public static void main(String[] args) 
	{
		VarArgsExp obj=new VarArgsExp();
		obj.display();
		obj.display(null);
		obj.display("hello");
		obj.display("welcome","how");
	}
	void display(String...data)
	{
		System.out.println(("In display "+data));
		//for(String str:data)
			//System.out.println(str);
	}

}
