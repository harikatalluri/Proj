public class Test
{
	public static void main(String args[])
	{
		try
		{
			return;
		}
		finally
		{
			System.out.println("Final");
		}
	}
}


/*public class Test
{
	public static void main(String args[])
	{
		try
		{
			System.out.println("Hello");
			System.exit(0);
			System.out.println("Hi");
		}
		catch(Exception e)
		{
			System.err.println("Exception");
		}
		finally
		{
			System.out.println("Resources closed");
		}
	}
}*/




/*class Base{
 Base(int var)
 {
     System.out.println("Base");
 }
 }
 class Test extends Base{
 public static void main(String argv[]){
         Test obj = new Test();
 }
 }*/ 