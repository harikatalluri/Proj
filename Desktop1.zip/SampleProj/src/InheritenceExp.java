public class InheritenceExp 
{
	public static void main(String[] args) 
	{
		Primate p=new Primate();
		Human h=new Human();
		p.walk();
		p.jump();
		h.walk();
		h.eat();
		h.sleep();
		h.think();
		h.talk();
	}
}

class Primate
{
	public void eat()
	{
		System.out.println("Any primate can eat");
	}
	public void sleep()
	{
		System.out.println("Any primate can sleep");
	}
	public void walk()
	{
		System.out.println("Any primate can walk");
	}
	public void jump()
	{
		System.out.println("Any primate can jump");
	}
}

class Human extends Primate
{
	public void think()
	{
		System.out.println("Any human can think");
	}
	public void talk()
	{
		System.out.println("Any human can talk");
	}
	public void walk()
	{
		System.out.println("Any human can walk");
	}
}
