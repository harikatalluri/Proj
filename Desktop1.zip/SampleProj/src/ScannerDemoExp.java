import java.util.*;
public class ScannerDemoExp 
{
	public static void main(String[] args) 
	{
		Scanner scan=new Scanner("1,2,3,4,5,6,7,8").useDelimiter(",");
		while(scan.hasNextInt())
		{
			int num=scan.nextInt();
			if(num%2==0)
				System.out.println("Number "+num+" is even");
		}
	}
}


/* import java.util.*; 
public class ScannerDemo 
{
	public static void main(String[] args) 
	{
		Scanner scan=new Scanner("1 2 3 4 5 6 7 8");
		while(scan.hasNextInt())
		{
			int num=scan.nextInt();
			if(num%2==0)
				System.out.println("Number "+num+" is even");
		}
	}
}*/


/* import java.util.*; 
public class ScannerDemo 
{
	public static void main(String[] args) 
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter numbers: ");
		while(scan.hasNextInt())
		{
			int num=scan.nextInt();
			if(num%2==0)
				System.out.println("Number is even");
		}
	}
}*/


/*import java.util.*; 
public class ScannerDemo 
{
	public static void main(String[] args) 
	{
		int i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		i=sc.nextInt();
		System.out.println("The entered number is: "+i);
	}
}	*/


