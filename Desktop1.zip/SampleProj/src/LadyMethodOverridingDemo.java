public class LadyMethodOverridingDemo 
{
	public static void main(String args[])
	{
		Employe e=new Employe();
		HomeMaker h=new HomeMaker();
		Member m=new Member();
	}
}

class Lady
{
	public void work()
	{
		System.out.println("Lady works all the time");
	}
}

class Employe extends Lady
{
	public void work()
	{
		System.out.println("Works as employee");
	}
	public void coding()
	{
		System.out.println("Does coding");
	}
}

class HomeMaker extends Lady
{
	public void work()
	{
		System.out.println("Works as homemaker");		
	}
	public void cook()
	{
		System.out.println("Does cooking");
	}
}

class Member extends Lady
{
	public void work()
	{
		System.out.println("Works as member");		
	}
	public void manages()
	{
		System.out.println("Does managing");
	}
}
