import java.util.*;
public class IpAddress 
{
	public static void main(String[] args) 
	{
		IpAddress ip=new IpAddress();
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter an IP Address: ");
		String ipaddr=scan.nextLine();
		ip.validateIpAddress(ipaddr);
	}
	public void validateIpAddress(String Ipaddr) 
	{
		String part[]=Ipaddr.split("\\.");
		if(part.length!=4)
		{
			System.out.println("Not a valid IP address.");
		}
		else
		{
			for(String str:part)
			{
				int subpart=Integer.parseInt(str);
				if(subpart<0 || subpart>255)
				{
					System.out.println("Not a valid IP address.");
					System.exit(0);
				}
			}
			System.out.println("It is a valid IP Address");
		}
	}
}