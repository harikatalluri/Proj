public class StudentDPInstanceOfDemo 
{
	public static void main(String args[])
	{
		/* Student s=new Student();
		Regular r=new Regular();
		Hosteler h=new Hosteler();
		s=h;
		s.study();
		//s.payHostelFee();	*/
		
		Student s=new Regular();
		
		if(s instanceof Regular)
		{
			s.study();
			//s.payBusFee();	not possible	
			Regular r=(Regular)s;
			r.study();
			r.payBusFee();
		}
		else if(s instanceof Hosteler)
		{
			s.study();
			//s.payBusFee();	not possible	
			Hosteler h=(Hosteler)s;
			h.study();
			h.payHostelFee();
		}
		
		/* Student s=new Regular();
		s.study();
		//s.payBusFee();	Error:s cannot access independent method of regular
		
		//So go for explicit type casting
		Regular r=(Regular)s;
		r.study();
		r.payBusFee();
		
		//Hosteler h=(Hosteler)s;	Error:Regular cannot cast to hosteler
		//h.payHostelFee();	*/
	}

}

class Student
{
	void study()
	{
		System.out.println("Student studies");
	}
}

class Regular extends Student
{
	void study()
	{
		System.out.println("Regular Student studies");
	}
	void payBusFee()
	{
		System.out.println("Regular Student pays bus fee");
	}
}

class Hosteler extends Student
{
	void study()
	{
		System.out.println("Hosteler Student studies");
	}
	void payHostelFee()
	{
		System.out.println("Hostel Student pays hostel fee");
	}
}
