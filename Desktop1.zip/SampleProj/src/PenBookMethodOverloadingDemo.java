public class PenBookMethodOverloadingDemo 
{
	public static void main(String[] args) 
	{
		PenBookMethodOverloadingDemo exp=new PenBookMethodOverloadingDemo();
		exp.provide();
		exp.provide(8);
		exp.provide("notes");
		exp.provide(5,"novel");
		exp.provide("textbook",6);
	}
	public void provide()
	{
		System.out.println("No need to provide");
	}
	public void provide(int pen)
	{
		System.out.println("Need to provide pen "+pen);
	}
	public void provide(String book)
	{
		System.out.println("Need to provide book "+book);
	}
	public void provide(int pen,String book)
	{
		System.out.println("Need to provide pen and book "+pen+" "+book);
	}
	public void provide(String book,int pen)
	{
		System.out.println("Need to provide book and pen "+book+" "+pen);
	}
}
