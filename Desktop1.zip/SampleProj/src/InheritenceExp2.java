
public class InheritenceExp2 
{
	public static void main(String[] args) 
	{
		ElectronicDevice e=new ElectronicDevice();
		Tv t=new Tv();
		DvdPlayer d=new DvdPlayer();
		Radio r=new Radio();
	}
}

class ElectronicDevice
{
	public void RemoteControl()
	{
		System.out.println("This can be controlled with remote");
	}
	public void listenAudio()
	{
		System.out.println("This can be used to listen audio");
	}
	
	
}

class Tv extends ElectronicDevice
{
	public void Display()
	{
		System.out.println("This can be used to see video");
	}
}

class DvdPlayer extends Tv
{
	
}

class Radio extends ElectronicDevice
{
	
}

