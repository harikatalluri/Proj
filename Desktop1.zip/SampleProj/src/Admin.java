class AdminExp
{
	private String role;
	private String name;
	private float salary;
	
	public String getRole() {
		return role;
	}

	public String getName() {
		return name;
	}

	public float getSalary() {
		return salary;
	}
	
	AdminExp(String role,String name,float salary)
	{
		this.role=role;
		this.name=name;
		this.salary=salary;
	}
}

public class Admin
{
	public static void main(String[] args) 
	{
		AdminExp emp1=new AdminExp("Analyst","Harika",17000.50F);
		AdminExp emp2=new AdminExp("Analyst","Teja",17000.50F);
		System.out.println("Role of emp1 is: " +emp1.getRole());
		System.out.println("Name of emp1 is: " +emp1.getName());
		System.out.println("Salary of emp1 is: " +emp1.getSalary());
		System.out.println("Role of emp2 is: " +emp2.getRole());
		System.out.println("Name of emp2 is: " +emp2.getName());
		System.out.println("Salary of emp2 is: " +emp2.getSalary());
	}

}
