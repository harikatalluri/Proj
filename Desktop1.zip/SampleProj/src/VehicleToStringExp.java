public class VehicleToStringExp 
{
	private int regNo;
	private String vehName;
	
	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}
	public void setVehName(String vehName) {
		this.vehName = vehName;
	}
	public static void main(String[] args) 
	{
		VehicleToStringExp v=new VehicleToStringExp();
		v.setRegNo(9999);
		v.setVehName("baleno");
		System.out.println("Vehicle details: "+v.toString());
	}
	@Override
	public String toString()
	{
		return regNo+" "+vehName;
	}
}