import java.util.Scanner;
public class NumberToString 
{
	public static void main(String[] args) 
	{
		int[] digit = new int[20];
		String values[]={"zero","one","two","three","four","five","six","seven","eight","nine"};
		int index=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num=sc.nextInt();
		while(num!=0)
		{
			digit[index]=num%10;
			num=num/10;
			index++;
		}
		for(int i=index-1;i>=0;i--)
			System.out.print(values[digit[i]]+" ");
	}
}
