class Box
{
	private int width;
	private int height;
	private int depth;
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	public int getDepth() {
		return depth;
	}
	
	/* public void setWidth(int width) {
		this.width = width;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public void setDepth(int depth) {
		this.depth = depth;
	} 	*/
	
	//Setters are not required since we are using constructor to give values
	
	Box()		//This is a no argument constructor. 
	{			//This is not required to be declare if only b1 exists in program.
		
	}
	
	Box(int w,int h,int d)
	{
		this.width=w;
		this.height=h;
		this.depth=d;
	}
	
	int calVol()
	{
		return width*height*depth;
	}
}

public class BoxDemoExample
{
	public static void main(String[] args) 
	{
		Box b1=new Box();
		Box b2=new Box(10,20,30);
		Box b3=new Box(5,6,7);
		System.out.println("Width of box1 is: " +b1.getWidth());
		System.out.println("Height of box1 is: " +b1.getHeight());
		System.out.println("Depth of box1 is: " +b1.getDepth());
		System.out.println("Volume of box1 is: "+b1.calVol());
		System.out.println("Width of box2 is: " +b2.getWidth());
		System.out.println("Height of box2 is: " +b2.getHeight());
		System.out.println("Depth of box2 is: " +b2.getDepth());
		System.out.println("Volume of box2 is: "+b2.calVol());
		System.out.println("Width of box3 is: " +b3.getWidth());
		System.out.println("Height of box3 is: " +b3.getHeight());
		System.out.println("Depth of box3 is: " +b3.getDepth());
		System.out.println("Volume of box3 is: "+b3.calVol());
	}

}
